import os

def create_file(path, content):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, 'w', encoding='utf-8') as f:
        f.write(content.strip() + '\n')

def main():
    base_dir = "streamlit_app"
    os.makedirs(base_dir, exist_ok=True)
    
    # ---------------------------------------------------------
    # REQUIREMENTS & README
    # ---------------------------------------------------------
    create_file(f"{base_dir}/requirements.txt", """
streamlit==1.32.0
pandas==2.2.1
plotly==5.19.0
numpy==1.26.4
""")

    create_file(f"{base_dir}/README.md", """
# Streamlit Conversion

## Setup
1. `pip install -r requirements.txt`
2. `streamlit run app.py`
""")

    # ---------------------------------------------------------
    # UTILS
    # ---------------------------------------------------------
    create_file(f"{base_dir}/utils/state.py", """
import streamlit as st

def init_session_state():
    if "app_state" not in st.session_state:
        st.session_state.app_state = "preparation"  # 'preparation' or 'execution'
    if "uploaded_file" not in st.session_state:
        st.session_state.uploaded_file = None
    if "upload_state" not in st.session_state:
        st.session_state.upload_state = "empty" # empty, valid, processing, ready
    if "active_module_id" not in st.session_state:
        st.session_state.active_module_id = "clustering"
    
    if "pipeline_stages" not in st.session_state:
        st.session_state.pipeline_stages = {
            "read": "WAITING",
            "extract": "WAITING",
            "preprocess": "WAITING"
        }
""")

    # ---------------------------------------------------------
    # APP.PY
    # ---------------------------------------------------------
    create_file(f"{base_dir}/app.py", """
import streamlit as st
from utils.state import init_session_state
from components.header import render_header
from components.workflow_upload import render_workflow_upload
from components.preparation_pipeline import render_preparation_pipeline
from pages.execution import render_execution_platform
import time

st.set_page_config(
    page_title="AI-Driven Data Center",
    page_icon="🌍",
    layout="wide",
    initial_sidebar_state="expanded"
)

init_session_state()

# Custom CSS for styling to match React
st.markdown(\"\"\"
    <style>
    .stApp {
        background-color: #09090b;
        color: #fafafa;
    }
    /* Simple CSS reset/match */
    .css-1d391kg {
        background-color: #09090b;
    }
    div[data-testid="stSidebar"] {
        background-color: #09090b;
        border-right: 1px solid #27272a;
    }
    /* Headers */
    h1, h2, h3 {
        color: #fafafa !important;
    }
    .metric-card {
        background-color: #18181b;
        border: 1px solid #27272a;
        border-radius: 0.5rem;
        padding: 1rem;
    }
    .status-badge {
        display: inline-block;
        padding: 0.25rem 0.75rem;
        border-radius: 9999px;
        font-size: 0.75rem;
        font-weight: 600;
        text-transform: uppercase;
    }
    .status-waiting { background-color: #27272a; color: #a1a1aa; }
    .status-processing { background-color: #0284c720; color: #38bdf8; border: 1px solid #0284c750; }
    .status-completed { background-color: #16653420; color: #4ade80; border: 1px solid #16653450; }
    </style>
\"\"\", unsafe_allow_html=True)

def main():
    render_header()
    
    if st.session_state.app_state == "preparation":
        st.markdown("<h2 style='text-align: center;'>Workflow Intake</h2>", unsafe_allow_html=True)
        col1, col2 = st.columns([2, 1])
        
        with col1:
            render_workflow_upload()
            
        with col2:
            st.markdown("### Workflow Snapshot")
            if st.session_state.uploaded_file:
                st.info(f"File: {st.session_state.uploaded_file.name}\\nStatus: Validated")
            else:
                st.warning("No workflow loaded.")
                
        st.markdown("---")
        render_preparation_pipeline()
        
        if st.session_state.upload_state == "valid":
            if st.button("CHECK WORKFLOW", use_container_width=True, type="primary"):
                st.session_state.upload_state = "processing"
                st.rerun()
                
        if st.session_state.upload_state == "processing":
            # Simulate pipeline
            progress_bar = st.progress(0)
            status_text = st.empty()
            
            status_text.text("Reading Workflow...")
            time.sleep(1)
            st.session_state.pipeline_stages["read"] = "COMPLETED"
            st.session_state.pipeline_stages["extract"] = "PROCESSING"
            progress_bar.progress(33)
            
            status_text.text("Extracting Info...")
            time.sleep(1.5)
            st.session_state.pipeline_stages["extract"] = "COMPLETED"
            st.session_state.pipeline_stages["preprocess"] = "PROCESSING"
            progress_bar.progress(66)
            
            status_text.text("Preprocessing...")
            time.sleep(1.5)
            st.session_state.pipeline_stages["preprocess"] = "COMPLETED"
            progress_bar.progress(100)
            
            status_text.text("Workflow Ready!")
            time.sleep(1)
            
            st.session_state.upload_state = "ready"
            st.session_state.app_state = "execution"
            st.session_state.active_module_id = "clustering"
            st.rerun()
            
    elif st.session_state.app_state == "execution":
        render_execution_platform()

if __name__ == "__main__":
    main()
""")

    # ---------------------------------------------------------
    # COMPONENTS / PAGES
    # ---------------------------------------------------------
    create_file(f"{base_dir}/components/header.py", """
import streamlit as st

def render_header():
    st.markdown(\"\"\"
        <div style='text-align: center; padding: 1rem 0; border-bottom: 1px solid #27272a; margin-bottom: 2rem;'>
            <h1 style='margin: 0; font-size: 1.5rem;'>AI-Driven Carbon-Aware Dynamic Workflow Scheduling</h1>
            <h3 style='margin: 0; color: #a1a1aa; font-weight: normal;'>with Intelligent Resource Optimization for Sustainable Green Cloud Data Centers</h3>
        </div>
    \"\"\", unsafe_allow_html=True)
""")

    create_file(f"{base_dir}/components/workflow_upload.py", """
import streamlit as st

def render_workflow_upload():
    st.markdown("### Upload DAX/XML Workflow")
    uploaded_file = st.file_uploader("Select Workflow File", type=["xml", "dax"])
    if uploaded_file is not None:
        if st.session_state.uploaded_file != uploaded_file:
            st.session_state.uploaded_file = uploaded_file
            st.session_state.upload_state = "valid"
            # reset pipeline
            st.session_state.pipeline_stages = {
                "read": "WAITING", "extract": "WAITING", "preprocess": "WAITING"
            }
            st.rerun()
""")

    create_file(f"{base_dir}/components/preparation_pipeline.py", """
import streamlit as st

def render_preparation_pipeline():
    st.markdown("<h3 style='text-align: center;'>Preparation Pipeline</h3>", unsafe_allow_html=True)
    cols = st.columns(3)
    
    stages = [
        ("01", "READ WORKFLOW", st.session_state.pipeline_stages["read"]),
        ("02", "EXTRACT INFO", st.session_state.pipeline_stages["extract"]),
        ("03", "PREPROCESS", st.session_state.pipeline_stages["preprocess"])
    ]
    
    for i, col in enumerate(cols):
        num, title, state = stages[i]
        with col:
            st.markdown(f\"\"\"
                <div class='metric-card' style='text-align: center;'>
                    <div style='color: #a1a1aa; font-size: 0.8rem;'>{num}</div>
                    <div style='font-weight: bold; margin: 0.5rem 0;'>{title}</div>
                    <span class='status-badge status-{state.lower()}'>{state}</span>
                </div>
            \"\"\", unsafe_allow_html=True)
""")

    create_file(f"{base_dir}/pages/execution.py", """
import streamlit as st
from modules.m01_clustering import render as render_clustering
from modules.m02_resource_monitoring import render as render_resource
from modules.m03_renewable_energy import render as render_renewable
from modules.m04_weather_carbon import render as render_weather
from modules.m05_carbon_prediction import render as render_carbon
from modules.m06_carbon_scheduler import render as render_scheduler
from modules.m07_cloudsim import render as render_cloudsim
from modules.m08_vm_migration import render as render_migration
from modules.m09_power_management import render as render_power
from modules.m10_failure_prediction import render as render_failure
from modules.m11_sustainability import render as render_sustainability
from modules.m12_system_health import render as render_health

MODULES = [
    ('clustering', '01. Dynamic Workflow Clustering', render_clustering),
    ('resources', '02. Resource Monitoring', render_resource),
    ('renewable', '03. Renewable Energy Prediction', render_renewable),
    ('weather', '04. Weather-Aware Carbon Forecast', render_weather),
    ('carbon', '05. AI-Based Carbon Prediction', render_carbon),
    ('scheduler', '06. Intelligent Resource Scheduler', render_scheduler),
    ('simulation', '07. CloudSim Plus Simulation', render_cloudsim),
    ('migration', '08. VM Migration', render_migration),
    ('power', '09. AI Server Power Management', render_power),
    ('failure', '10. Self-Healing Failure Prediction', render_failure),
    ('results', '11. Sustainability Dashboard', render_sustainability),
    ('system', '12. System Health', render_health)
]

def render_execution_platform():
    # Sidebar Navigation
    st.sidebar.markdown("### Execution Pipeline")
    
    module_ids = [m[0] for m in MODULES]
    
    # Handle direct clicks from sidebar buttons
    for m_id, m_title, _ in MODULES:
        if st.sidebar.button(
            m_title, 
            key=f"nav_{m_id}", 
            use_container_width=True,
            type="primary" if st.session_state.active_module_id == m_id else "secondary"
        ):
            st.session_state.active_module_id = m_id
            st.rerun()

    current_idx = module_ids.index(st.session_state.active_module_id)
    _, current_title, current_render_fn = MODULES[current_idx]
    
    st.markdown(f"## {current_title}")
    st.markdown("---")
    
    # Render active module
    current_render_fn()
    
    st.markdown("---")
    col_back, col_next = st.columns([1, 1])
    
    with col_back:
        if st.button("← BACK", use_container_width=True):
            if current_idx == 0:
                st.session_state.app_state = "preparation"
            else:
                st.session_state.active_module_id = module_ids[current_idx - 1]
            st.rerun()
            
    with col_next:
        if current_idx < len(module_ids) - 1:
            if st.button("NEXT →", use_container_width=True, type="primary"):
                st.session_state.active_module_id = module_ids[current_idx + 1]
                st.rerun()
""")

    # ---------------------------------------------------------
    # MODULES
    # ---------------------------------------------------------
    create_file(f"{base_dir}/modules/m01_clustering.py", """
import streamlit as st
def render():
    st.write("Dynamic Workflow Clustering Interface")
    st.info("Backend clustering algorithm not connected. Showing empty state.")
    col1, col2 = st.columns(2)
    with col1:
        st.markdown("<div class='metric-card'>Tasks Uploaded: N/A</div>", unsafe_allow_html=True)
    with col2:
        st.markdown("<div class='metric-card'>Suggested Clusters: N/A</div>", unsafe_allow_html=True)
""")

    create_file(f"{base_dir}/modules/m02_resource_monitoring.py", """
import streamlit as st
def render():
    st.write("Resource Monitoring Interface")
    st.info("No server telemetry connected. WAITING state active.")
""")
    create_file(f"{base_dir}/modules/m03_renewable_energy.py", """
import streamlit as st
def render():
    st.write("Renewable Energy Prediction (Residual LSTM V2)")
    st.warning("Model disconnected. No forecast available.")
""")
    create_file(f"{base_dir}/modules/m04_weather_carbon.py", """
import streamlit as st
def render():
    st.write("Weather-Aware Carbon Forecast (NASA POWER)")
    st.warning("Weather API disconnected. No forecast available.")
""")
    create_file(f"{base_dir}/modules/m05_carbon_prediction.py", """
import streamlit as st
def render():
    st.write("AI-Based Carbon Prediction (Electricity Maps / LSTM)")
    st.warning("Carbon grid API disconnected.")
""")
    create_file(f"{base_dir}/modules/m06_carbon_scheduler.py", """
import streamlit as st
def render():
    st.write("Carbon-Aware Intelligent Resource Scheduler")
    st.info("Awaiting predictions and resource telemetry.")
""")
    create_file(f"{base_dir}/modules/m07_cloudsim.py", """
import streamlit as st
def render():
    st.write("CloudSim Plus Simulation Engine")
    st.info("Simulation backend unavailable.")
""")
    create_file(f"{base_dir}/modules/m08_vm_migration.py", """
import streamlit as st
def render():
    st.write("VM Migration & Consolidation")
    st.info("Waiting for overloaded server detection.")
""")
    create_file(f"{base_dir}/modules/m09_power_management.py", """
import streamlit as st
def render():
    st.write("AI-Based Server Power Management (DVFS / Sleep)")
    st.info("Power state telemetry unavailable.")
""")
    create_file(f"{base_dir}/modules/m10_failure_prediction.py", """
import streamlit as st
def render():
    st.write("Self-Healing Failure Prediction")
    st.info("No anomaly trends detected.")
""")
    create_file(f"{base_dir}/modules/m11_sustainability.py", """
import streamlit as st
def render():
    st.write("Sustainability Monitoring Dashboard")
    st.info("Awaiting execution results to populate dashboard.")
""")
    create_file(f"{base_dir}/modules/m12_system_health.py", """
import streamlit as st
def render():
    st.write("System Health")
    st.error("Backend services disconnected.")
""")

if __name__ == "__main__":
    main()
    print("Streamlit files generated successfully.")
