import os
import shutil

def create_file(path, content):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, 'w', encoding='utf-8') as f:
        f.write(content.strip() + '\n')

def generate_app():
    base_dir = "streamlit_app"
    
    # -------------------------------------------------------------------------
    # UTILS / THEME
    # -------------------------------------------------------------------------
    create_file(f"{base_dir}/utils/theme.py", """
import streamlit as st

def apply_theme():
    # Provide a UI toggle for theme
    if 'theme' not in st.session_state:
        st.session_state.theme = 'dark'
        
    theme = st.session_state.theme
    
    if theme == 'dark':
        css = \"\"\"
        :root {
            --background: #09090b;
            --foreground: #fafafa;
            --surface: #18181b;
            --surface-elevated: #27272a;
            --border: #27272a;
            --accent: #2563eb;
            --accent-foreground: #ffffff;
            --muted: #a1a1aa;
            --muted-foreground: #71717a;
            --processing: #38bdf8;
            --error: #f87171;
            --warning: #fbbf24;
            --success: #4ade80;
        }
        \"\"\"
    else:
        css = \"\"\"
        :root {
            --background: #ffffff;
            --foreground: #09090b;
            --surface: #f4f4f5;
            --surface-elevated: #e4e4e7;
            --border: #e4e4e7;
            --accent: #2563eb;
            --accent-foreground: #ffffff;
            --muted: #52525b;
            --muted-foreground: #a1a1aa;
            --processing: #0284c7;
            --error: #ef4444;
            --warning: #f59e0b;
            --success: #22c55e;
        }
        \"\"\"

    global_css = \"\"\"
    <style>
    /* Reset & Base */
    .stApp {
        background-color: var(--background);
        color: var(--foreground);
        font-family: ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
    }
    
    /* Hide default header */
    header[data-testid="stHeader"] {
        display: none !important;
    }
    
    /* Layout adjustments */
    .block-container {
        padding-top: 0rem !important;
        padding-bottom: 2rem !important;
        max-width: 1400px;
    }
    
    /* Streamlit overrides */
    div[data-testid="stSidebar"] {
        background-color: var(--background);
        border-right: 1px solid var(--border);
    }
    
    /* Cards */
    .react-card {
        background-color: var(--surface);
        border: 1px solid var(--border);
        border-radius: 1rem;
        padding: 1.5rem;
        box-shadow: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
    }
    .react-card-header {
        font-size: 0.875rem;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        color: var(--foreground);
        border-bottom: 1px solid var(--border);
        padding-bottom: 1rem;
        margin-bottom: 1rem;
    }
    
    /* Metric Item */
    .metric-box {
        background-color: var(--surface-elevated);
        border: 1px solid var(--border);
        border-radius: 0.5rem;
        padding: 1rem;
        height: 100%;
        display: flex;
        flex-direction: column;
    }
    .metric-title {
        color: var(--muted);
        font-size: 0.75rem;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        margin-bottom: 0.5rem;
    }
    .metric-value {
        font-size: 1.5rem;
        font-weight: 700;
        color: var(--foreground);
    }
    .metric-subtitle {
        color: var(--muted-foreground);
        font-size: 0.75rem;
        margin-top: 0.25rem;
    }
    
    /* Status Badges */
    .badge {
        display: inline-flex;
        align-items: center;
        padding: 0.25rem 0.75rem;
        border-radius: 9999px;
        font-size: 0.75rem;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.05em;
    }
    .badge-waiting { background-color: var(--surface-elevated); color: var(--muted); border: 1px solid var(--border); }
    .badge-processing { background-color: rgba(56, 189, 248, 0.1); color: var(--processing); border: 1px solid rgba(56, 189, 248, 0.2); }
    .badge-success { background-color: rgba(74, 222, 128, 0.1); color: var(--success); border: 1px solid rgba(74, 222, 128, 0.2); }
    .badge-warning { background-color: rgba(251, 191, 36, 0.1); color: var(--warning); border: 1px solid rgba(251, 191, 36, 0.2); }
    .badge-error { background-color: rgba(248, 113, 113, 0.1); color: var(--error); border: 1px solid rgba(248, 113, 113, 0.2); }
    
    /* Sidebar Navigation List styling to override default buttons */
    .stButton.nav-button > button {
        width: 100%;
        text-align: left;
        background-color: transparent;
        border: none;
        color: var(--muted);
        padding: 0.5rem 0.75rem;
        justify-content: flex-start;
        font-weight: 500;
        border-radius: 0.5rem;
        transition: all 0.2s;
    }
    .stButton.nav-button > button:hover {
        background-color: var(--surface-elevated);
        color: var(--foreground);
    }
    .stButton.nav-button-active > button {
        background-color: rgba(37, 99, 235, 0.1);
        color: var(--accent);
        border: none;
        font-weight: 600;
    }
    .stButton.nav-button-active > button p, .stButton.nav-button > button p {
        font-size: 0.8rem;
    }
    
    /* Primary buttons */
    .stButton.primary-btn > button {
        background-color: var(--accent);
        color: var(--accent-foreground);
        border: none;
        border-radius: 0.5rem;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        padding: 0.75rem 2rem;
    }
    .stButton.primary-btn > button:hover {
        background-color: #1d4ed8;
        color: #ffffff;
    }
    
    /* Headings */
    h1, h2, h3, h4, h5, h6 { color: var(--foreground) !important; }
    p { color: var(--muted); }
    
    /* Dataframes */
    [data-testid="stDataFrame"] {
        border-radius: 0.5rem;
        border: 1px solid var(--border);
    }
    </style>
    \"\"\"
    
    st.markdown(global_css + css, unsafe_allow_html=True)
""")

    create_file(f"{base_dir}/utils/state.py", """
import streamlit as st

def init_session_state():
    if 'theme' not in st.session_state:
        st.session_state.theme = 'dark'
    if 'app_state' not in st.session_state:
        st.session_state.app_state = 'preparation'
    if 'uploaded_file_name' not in st.session_state:
        st.session_state.uploaded_file_name = None
    if 'upload_status' not in st.session_state:
        st.session_state.upload_status = 'empty' # empty, valid
    if 'active_module_id' not in st.session_state:
        st.session_state.active_module_id = 'clustering'
""")

    create_file(f"{base_dir}/utils/ui.py", """
import streamlit as st
import plotly.graph_objects as go

def metric_box(title, value, subtitle=""):
    st.markdown(f\"\"\"
    <div class="metric-box">
        <div class="metric-title">{title}</div>
        <div class="metric-value">{value}</div>
        <div class="metric-subtitle">{subtitle}</div>
    </div>
    \"\"\", unsafe_allow_html=True)

def status_badge(label, status="WAITING"):
    status_lower = status.lower().replace(" ", "-")
    st.markdown(f\"\"\"
    <div style="display: flex; justify-content: space-between; align-items: center; padding: 0.75rem; background-color: var(--surface-elevated); border: 1px solid var(--border); border-radius: 0.5rem; margin-bottom: 0.5rem;">
        <div style="font-weight: 500; color: var(--foreground); font-size: 0.875rem;">{label}</div>
        <div class="badge badge-{status_lower}">{status}</div>
    </div>
    \"\"\", unsafe_allow_html=True)

def empty_chart(title, height=300):
    theme = st.session_state.theme
    bg_color = "#18181b" if theme == "dark" else "#f4f4f5"
    text_color = "#a1a1aa" if theme == "dark" else "#71717a"
    
    fig = go.Figure()
    fig.add_annotation(text="NO DATA AVAILABLE", xref="paper", yref="paper", showarrow=False, font=dict(size=14, color=text_color))
    fig.update_layout(
        height=height, 
        template="plotly_dark" if theme == "dark" else "plotly_white", 
        title=dict(text=title, font=dict(size=14, color=text_color)), 
        margin=dict(l=0, r=0, t=40, b=0),
        paper_bgcolor=bg_color, 
        plot_bgcolor=bg_color,
        xaxis=dict(showgrid=False, zeroline=False, showticklabels=False),
        yaxis=dict(showgrid=False, zeroline=False, showticklabels=False)
    )
    return fig

def render_card_header(title):
    st.markdown(f'<div class="react-card-header">{title}</div>', unsafe_allow_html=True)
""")

    # -------------------------------------------------------------------------
    # COMPONENTS
    # -------------------------------------------------------------------------
    create_file(f"{base_dir}/components/header.py", """
import streamlit as st
import datetime
import streamlit.components.v1 as components

def render_header():
    # A true live clock requires Javascript. 
    # To keep it lightweight and not break Streamlit, we render a small HTML component for just the clock.
    theme = st.session_state.theme
    bg_color = "#09090b" if theme == "dark" else "#ffffff"
    text_color = "#fafafa" if theme == "dark" else "#09090b"
    border_color = "#27272a" if theme == "dark" else "#e4e4e7"
    accent = "#2563eb"
    
    html_code = f\"\"\"
    <div style="background-color: {bg_color}; border-bottom: 1px solid {border_color}; padding: 10px 20px; display: flex; justify-content: space-between; align-items: center; font-family: sans-serif;">
        <div style="display: flex; align-items: center; gap: 10px;">
            <div style="width: 24px; height: 24px; background-color: {accent}; border-radius: 4px;"></div>
            <span style="color: {text_color}; font-weight: bold; font-size: 16px;">Green Data Center</span>
            <span style="background-color: {accent}20; color: {accent}; padding: 2px 8px; border-radius: 12px; font-size: 12px; font-weight: bold;">v2.0.0</span>
        </div>
        <div style="display: flex; align-items: center; gap: 15px;">
            <div id="live-clock" style="color: {text_color}; opacity: 0.7; font-size: 14px; font-family: monospace;"></div>
        </div>
    </div>
    <script>
        function updateClock() {{
            document.getElementById('live-clock').innerText = new Date().toLocaleString();
        }}
        setInterval(updateClock, 1000);
        updateClock();
    </script>
    \"\"\"
    components.html(html_code, height=45, margin=0)
    
    # Theme toggle in pure streamlit
    col1, col2, col3 = st.columns([8,1,1])
    with col3:
        if st.button("🌓 Theme", use_container_width=True):
            st.session_state.theme = 'light' if st.session_state.theme == 'dark' else 'dark'
            st.rerun()
""")

    create_file(f"{base_dir}/components/module_navigation.py", """
import streamlit as st

CATEGORIES = {
    'WORKFLOW': [('clustering', '01. Dynamic Workflow Clustering'), ('resources', '02. Resource Monitoring')],
    'AI INTELLIGENCE': [('renewable', '03. Renewable Energy Prediction'), ('weather', '04. Weather-Aware Carbon Forecast'), ('carbon', '05. AI-Based Carbon Prediction')],
    'OPTIMIZATION': [('scheduler', '06. Intelligent Resource Scheduler')],
    'EXECUTION': [('simulation', '07. CloudSim Plus Simulation'), ('migration', '08. VM Migration'), ('power', '09. AI Server Power Management')],
    'RELIABILITY': [('failure', '10. Self-Healing Failure Prediction')],
    'RESULTS': [('results', '11. Sustainability Dashboard')],
    'SYSTEM': [('system', 'SYS. System Health')]
}

def render_sidebar():
    st.markdown('<div style="padding: 1rem 0;">', unsafe_allow_html=True)
    
    for category, modules in CATEGORIES.items():
        st.markdown(f'<div style="font-size: 10px; font-weight: bold; color: var(--muted-foreground); text-transform: uppercase; letter-spacing: 0.1em; margin-top: 1rem; margin-bottom: 0.5rem; padding-left: 0.5rem;">{category}</div>', unsafe_allow_html=True)
        for m_id, title in modules:
            is_active = st.session_state.active_module_id == m_id
            btn_class = "nav-button-active" if is_active else "nav-button"
            
            # Using custom styled buttons to mimic the React sidebar
            st.markdown(f'<div class="stButton {btn_class}">', unsafe_allow_html=True)
            if st.button(title, key=f"nav_{m_id}", use_container_width=True):
                st.session_state.active_module_id = m_id
                st.rerun()
            st.markdown('</div>', unsafe_allow_html=True)
            
    st.markdown('</div>', unsafe_allow_html=True)
""")

    create_file(f"{base_dir}/components/execution_platform.py", """
import streamlit as st
from components.module_navigation import render_sidebar
from modules import m01_clustering, m02_resource_monitoring, m03_renewable_energy, m04_weather_carbon, m05_carbon_prediction, m06_carbon_scheduler, m07_cloudsim, m08_vm_migration, m09_power_management, m10_failure_prediction, m11_sustainability, m12_system_health

MODULE_MAP = {
    'clustering': m01_clustering.render,
    'resources': m02_resource_monitoring.render,
    'renewable': m03_renewable_energy.render,
    'weather': m04_weather_carbon.render,
    'carbon': m05_carbon_prediction.render,
    'scheduler': m06_carbon_scheduler.render,
    'simulation': m07_cloudsim.render,
    'migration': m08_vm_migration.render,
    'power': m09_power_management.render,
    'failure': m10_failure_prediction.render,
    'results': m11_sustainability.render,
    'system': m12_system_health.render
}

ORDERED_IDS = list(MODULE_MAP.keys())

def render_execution():
    st.markdown(\"\"\"
    <div style="text-align: center; padding: 2rem 0; border-bottom: 1px solid var(--border); margin-bottom: 2rem;">
        <h2 style="margin: 0; font-size: 1.5rem; font-weight: 700;">AI-Driven Carbon-Aware Dynamic Workflow Scheduling</h2>
        <div style="color: var(--muted); font-size: 1.125rem; margin-top: 0.5rem;">with Intelligent Resource Optimization for Sustainable Green Cloud Data Centers</div>
    </div>
    \"\"\", unsafe_allow_html=True)
    
    # Execution Pipeline Indicator Placeholder
    st.markdown("<div style='text-align:center; padding: 1rem; color: var(--muted); border: 1px dashed var(--border); border-radius: 0.5rem; margin-bottom: 2rem;'>EXECUTION PIPELINE INDICATOR (See React App for visual reference)</div>", unsafe_allow_html=True)
    
    col_nav, col_work = st.columns([1, 4], gap="large")
    
    with col_nav:
        render_sidebar()
        
    with col_work:
        active_id = st.session_state.active_module_id
        
        # Render the specific module
        st.markdown('<div class="react-card">', unsafe_allow_html=True)
        if active_id in MODULE_MAP:
            MODULE_MAP[active_id]()
        st.markdown('</div>', unsafe_allow_html=True)
        
        # Navigation Buttons
        st.markdown("<br/>", unsafe_allow_html=True)
        c_back, c_space, c_next = st.columns([2, 6, 2])
        
        current_idx = ORDERED_IDS.index(active_id)
        
        with c_back:
            if st.button("← BACK", use_container_width=True):
                if current_idx == 0:
                    st.session_state.app_state = 'preparation'
                else:
                    st.session_state.active_module_id = ORDERED_IDS[current_idx - 1]
                st.rerun()
                
        with c_next:
            if current_idx < len(ORDERED_IDS) - 1:
                st.markdown('<div class="stButton primary-btn">', unsafe_allow_html=True)
                if st.button("NEXT →", use_container_width=True):
                    st.session_state.active_module_id = ORDERED_IDS[current_idx + 1]
                    st.rerun()
                st.markdown('</div>', unsafe_allow_html=True)
""")

    # -------------------------------------------------------------------------
    # MAIN APP ROUTER
    # -------------------------------------------------------------------------
    create_file(f"{base_dir}/app.py", """
import streamlit as st
from utils.state import init_session_state
from utils.theme import apply_theme
from components.header import render_header
from components.execution_platform import render_execution

st.set_page_config(page_title="AI Data Center", layout="wide", initial_sidebar_state="collapsed")

init_session_state()
apply_theme()

render_header()

if st.session_state.app_state == 'preparation':
    # INTENTIONAL NO-FAKE-DATA INTAKE
    st.markdown('<div class="react-card" style="max-width: 900px; margin: 2rem auto;">', unsafe_allow_html=True)
    st.markdown('<div class="react-card-header">Workflow Intake</div>', unsafe_allow_html=True)
    
    col1, col2 = st.columns(2)
    with col1:
        st.markdown("### Upload DAX/XML Workflow")
        uploaded = st.file_uploader("Select file", type=["xml", "dax"])
        if uploaded:
            st.session_state.uploaded_file_name = uploaded.name
            st.session_state.upload_status = 'valid'
            
    with col2:
        st.markdown("### Workflow Snapshot")
        if st.session_state.uploaded_file_name:
            st.success(f"File validated: {st.session_state.uploaded_file_name}")
            st.info("Backend WorkflowSim parser NOT CONNECTED. Data extraction is pending.")
        else:
            st.markdown("<div style='padding: 2rem; border: 1px dashed var(--border); border-radius: 0.5rem; text-align: center; color: var(--muted);'>No workflow loaded.</div>", unsafe_allow_html=True)
            
    st.markdown("---")
    st.markdown("### Preparation Pipeline")
    c_p1, c_p2, c_p3 = st.columns(3)
    
    # We do NOT use time.sleep(). We show honest status.
    status = "WAITING" if st.session_state.upload_status == 'empty' else "READY FOR BACKEND"
    color_class = "badge-waiting" if status == "WAITING" else "badge-success"
    
    with c_p1:
        st.markdown(f\"\"\"<div class="metric-box" style="text-align: center;">
            <div class="metric-title">01 READ WORKFLOW</div>
            <div class="badge {color_class}">{status}</div>
        </div>\"\"\", unsafe_allow_html=True)
    with c_p2:
        st.markdown(f\"\"\"<div class="metric-box" style="text-align: center;">
            <div class="metric-title">02 EXTRACT INFO</div>
            <div class="badge {color_class}">{status}</div>
        </div>\"\"\", unsafe_allow_html=True)
    with c_p3:
        st.markdown(f\"\"\"<div class="metric-box" style="text-align: center;">
            <div class="metric-title">03 PREPROCESS</div>
            <div class="badge {color_class}">{status}</div>
        </div>\"\"\", unsafe_allow_html=True)
        
    st.markdown("<br/>", unsafe_allow_html=True)
    
    # Manual override to proceed
    col_btn = st.columns([1,2,1])[1]
    with col_btn:
        st.markdown('<div class="stButton primary-btn">', unsafe_allow_html=True)
        if st.button("PROCEED TO EXECUTION (Bypass Backend)", use_container_width=True, disabled=st.session_state.upload_status == 'empty'):
            st.session_state.app_state = 'execution'
            st.rerun()
        st.markdown('</div>', unsafe_allow_html=True)
        
    st.markdown('</div>', unsafe_allow_html=True)
    
elif st.session_state.app_state == 'execution':
    render_execution()
""")

    # -------------------------------------------------------------------------
    # MODULES (12 Files)
    # -------------------------------------------------------------------------
    create_file(f"{base_dir}/modules/m01_clustering.py", """
import streamlit as st
import pandas as pd
from utils.ui import render_card_header, metric_box, status_badge, empty_chart

def render():
    st.markdown("<h2>Dynamic Workflow Clustering</h2>", unsafe_allow_html=True)
    st.markdown("<p>Groups workflow tasks dynamically to optimize execution and minimize overhead.</p>", unsafe_allow_html=True)
    
    status_badge("Clustering Backend Status", "WAITING FOR WORKFLOW PROCESSING")
    
    st.markdown("<br/>", unsafe_allow_html=True)
    c1, c2, c3 = st.columns(3)
    with c1: metric_box("Total Tasks", "N/A", "Awaiting parsed data")
    with c2: metric_box("Optimal Clusters (k)", "N/A", "Elbow method result")
    with c3: metric_box("Silhouette Score", "N/A", "Model confidence")
    
    st.markdown("<br/>", unsafe_allow_html=True)
    render_card_header("K-Means Feature Space")
    st.plotly_chart(empty_chart("Task Clustering Distribution"), use_container_width=True)
    
    st.markdown("<br/>", unsafe_allow_html=True)
    render_card_header("Task Assignment Table")
    df = pd.DataFrame(columns=["Task ID", "CPU Required", "RAM Required", "Execution Time", "Assigned Cluster"])
    st.dataframe(df, use_container_width=True, hide_index=True)
""")

    create_file(f"{base_dir}/modules/m02_resource_monitoring.py", """
import streamlit as st
import pandas as pd
from utils.ui import render_card_header, metric_box, status_badge, empty_chart

def render():
    st.markdown("<h2>Resource Monitoring</h2>", unsafe_allow_html=True)
    st.markdown("<p>Monitors real-time resource utilization across the cloud data center.</p>", unsafe_allow_html=True)
    
    status_badge("Google/Alibaba Cluster Trace", "WAITING FOR RESOURCE TRACE")
    
    st.markdown("<br/>", unsafe_allow_html=True)
    c1, c2, c3 = st.columns(3)
    with c1: metric_box("Avg CPU Utilization", "NO DATA", "Across all nodes")
    with c2: metric_box("Avg RAM Utilization", "NO DATA", "Across all nodes")
    with c3: metric_box("Active Nodes", "0 / 0", "Servers online")
    
    st.markdown("<br/>", unsafe_allow_html=True)
    c_chart1, c_chart2 = st.columns(2)
    with c_chart1: 
        render_card_header("CPU Utilization (%)")
        st.plotly_chart(empty_chart("CPU Utilization Timeline"), use_container_width=True)
    with c_chart2: 
        render_card_header("RAM Utilization (%)")
        st.plotly_chart(empty_chart("RAM Utilization Timeline"), use_container_width=True)
    
    st.markdown("<br/>", unsafe_allow_html=True)
    render_card_header("Server Comparison")
    df = pd.DataFrame(columns=["Server ID", "CPU (%)", "RAM (%)", "Status", "Power Draw (W)"])
    st.dataframe(df, use_container_width=True, hide_index=True)
""")

    create_file(f"{base_dir}/modules/m03_renewable_energy.py", """
import streamlit as st
import pandas as pd
from utils.ui import render_card_header, metric_box, status_badge, empty_chart

def render():
    st.markdown("<h2>Renewable Energy Prediction</h2>", unsafe_allow_html=True)
    st.markdown("<p>Forecasts renewable energy availability to support carbon-aware cloud scheduling.</p>", unsafe_allow_html=True)
    
    status_badge("Renewable Residual LSTM V2", "WAITING FOR RENEWABLE MODEL")
    
    st.markdown("<br/>", unsafe_allow_html=True)
    c1, c2, c3, c4 = st.columns(4)
    with c1: metric_box("Model Setup", "LSTM V2", "Residual Network architecture")
    with c2: metric_box("RMSE", "N/A", "Root Mean Square Error")
    with c3: metric_box("MAE", "N/A", "Mean Absolute Error")
    with c4: metric_box("R² Score", "N/A", "Coefficient of Determination")
    
    st.markdown("<br/>", unsafe_allow_html=True)
    render_card_header("Renewable Generation Forecast")
    st.plotly_chart(empty_chart("Total Renewable Generation (MU)"), use_container_width=True)
    
    st.markdown("<br/>", unsafe_allow_html=True)
    render_card_header("Prediction Timeline")
    df = pd.DataFrame(columns=["Timestamp", "Solar Predict (MU)", "Wind Predict (MU)", "Total Renewable (MU)", "Confidence"])
    st.dataframe(df, use_container_width=True, hide_index=True)
""")

    create_file(f"{base_dir}/modules/m04_weather_carbon.py", """
import streamlit as st
import pandas as pd
from utils.ui import render_card_header, metric_box, status_badge, empty_chart

def render():
    st.markdown("<h2>Weather-Aware Carbon Forecast</h2>", unsafe_allow_html=True)
    st.markdown("<p>Uses weather and environmental conditions to support carbon-intensity forecasting.</p>", unsafe_allow_html=True)
    
    status_badge("NASA POWER Data Source", "NOT CONNECTED")
    
    st.markdown("<br/>", unsafe_allow_html=True)
    c1, c2, c3 = st.columns(3)
    with c1: metric_box("Surface Temp (C)", "N/A", "Latest reading")
    with c2: metric_box("Cloud Cover (%)", "N/A", "Latest reading")
    with c3: metric_box("Wind Speed (m/s)", "N/A", "Latest reading")
    
    st.markdown("<br/>", unsafe_allow_html=True)
    render_card_header("Weather Trends & Correlation")
    st.plotly_chart(empty_chart("Weather-Aware Correlation Analysis"), use_container_width=True)
    
    st.markdown("<br/>", unsafe_allow_html=True)
    render_card_header("NASA POWER Correlation Data")
    df = pd.DataFrame(columns=["Timestamp", "Temp (C)", "Cloud (%)", "Wind (m/s)", "Solar Irradiance"])
    st.dataframe(df, use_container_width=True, hide_index=True)
""")

    create_file(f"{base_dir}/modules/m05_carbon_prediction.py", """
import streamlit as st
import pandas as pd
from utils.ui import render_card_header, metric_box, status_badge, empty_chart

def render():
    st.markdown("<h2>AI-Based Carbon Prediction</h2>", unsafe_allow_html=True)
    st.markdown("<p>Predict carbon intensity using AI-driven analysis to support carbon-aware scheduling.</p>", unsafe_allow_html=True)
    
    status_badge("Carbon Residual LSTM V2", "READY FOR BACKEND INTEGRATION")
    
    st.markdown("<br/>", unsafe_allow_html=True)
    c1, c2, c3 = st.columns(3)
    with c1: metric_box("Current Intensity", "N/A", "gCO2eq/kWh")
    with c2: metric_box("24h Forecast Avg", "N/A", "gCO2eq/kWh")
    with c3: metric_box("Grid Status", "NO DATA", "Awaiting data")
    
    st.markdown("<br/>", unsafe_allow_html=True)
    render_card_header("Carbon Intensity Forecast")
    st.plotly_chart(empty_chart("Carbon Intensity (gCO2eq/kWh)"), use_container_width=True)
    
    st.markdown("<br/>", unsafe_allow_html=True)
    render_card_header("Prediction Data Table")
    df = pd.DataFrame(columns=["Timestamp", "Predicted Intensity", "Actual Intensity", "Variance"])
    st.dataframe(df, use_container_width=True, hide_index=True)
""")

    create_file(f"{base_dir}/modules/m06_carbon_scheduler.py", """
import streamlit as st
import pandas as pd
from utils.ui import render_card_header, metric_box, status_badge

def render():
    st.markdown("<h2>Carbon-Aware Intelligent Resource Scheduler</h2>", unsafe_allow_html=True)
    st.markdown("<p>Schedules clustered tasks to the most sustainable servers.</p>", unsafe_allow_html=True)
    
    status_badge("Resource Scheduler", "WAITING FOR RESOURCE DATA")
    
    st.markdown("<br/>", unsafe_allow_html=True)
    c1, c2 = st.columns([2, 1], gap="large")
    
    with c1:
        render_card_header("Server Candidates")
        st.markdown("<div style='padding: 3rem 1rem; border: 1px dashed var(--border); border-radius: 0.5rem; text-align: center; color: var(--muted);'>No server candidates available. Awaiting resource trace data.</div>", unsafe_allow_html=True)
            
    with c2:
        render_card_header("Selected Assignment")
        metric_box("Target Node", "WAITING", "No workflow scheduled")
        st.markdown("<br/>", unsafe_allow_html=True)
        render_card_header("Reasoning")
        st.markdown("<p style='font-size: 0.875rem;'>Awaiting backend evaluation metrics for carbon intensity and scheduling scores.</p>", unsafe_allow_html=True)
        
    st.markdown("<br/>", unsafe_allow_html=True)
    render_card_header("Scheduling Queue")
    df = pd.DataFrame(columns=["Task ID", "Cluster", "Target Server", "Estimated Carbon", "Status"])
    st.dataframe(df, use_container_width=True, hide_index=True)
""")

    create_file(f"{base_dir}/modules/m07_cloudsim.py", """
import streamlit as st
import pandas as pd
from utils.ui import render_card_header, metric_box, status_badge, empty_chart

def render():
    st.markdown("<h2>CloudSim Plus Simulation</h2>", unsafe_allow_html=True)
    st.markdown("<p>Simulate scheduled workflow execution across cloud resources and evaluate behavior.</p>", unsafe_allow_html=True)
    
    status_badge("CloudSim Plus Backend", "READY FOR INTEGRATION")
    
    st.markdown("<br/>", unsafe_allow_html=True)
    st.progress(0, text="Simulation Progress: WAITING FOR START")
    
    st.markdown("<br/>", unsafe_allow_html=True)
    c1, c2, c3, c4 = st.columns(4)
    with c1: metric_box("Total Tasks", "N/A", "In simulation")
    with c2: metric_box("Tasks Completed", "0", "0%")
    with c3: metric_box("VMs Active", "0", "Provisioned")
    with c4: metric_box("Sim Time", "0ms", "Virtual execution")
    
    st.markdown("<br/>", unsafe_allow_html=True)
    c_chart1, c_chart2 = st.columns(2)
    with c_chart1: 
        render_card_header("Workflow Execution Status")
        st.plotly_chart(empty_chart("Task Execution Timeline (Gantt)"), use_container_width=True)
    with c_chart2: 
        render_card_header("Resource Usage Monitoring")
        st.plotly_chart(empty_chart("VM Resource Allocation"), use_container_width=True)
    
    st.markdown("<br/>", unsafe_allow_html=True)
    render_card_header("Simulation Output Tables")
    df = pd.DataFrame(columns=["Time", "Event", "Task", "VM", "Details"])
    st.dataframe(df, use_container_width=True, hide_index=True)
""")

    create_file(f"{base_dir}/modules/m08_vm_migration.py", """
import streamlit as st
import pandas as pd
from utils.ui import render_card_header, metric_box, status_badge

def render():
    st.markdown("<h2>VM Migration</h2>", unsafe_allow_html=True)
    st.markdown("<p>Optimizes VM placement through migration and resource consolidation.</p>", unsafe_allow_html=True)
    
    status_badge("Migration Engine", "WAITING FOR OVERLOAD DETECTION")
    
    st.markdown("<br/>", unsafe_allow_html=True)
    c1, c2 = st.columns(2)
    with c1:
        render_card_header("Source (Overloaded Server)")
        metric_box("Server ID", "N/A", "No overload detected")
    with c2:
        render_card_header("Destination (Candidate Server)")
        metric_box("Server ID", "N/A", "No target selected")
        
    st.markdown("<br/>", unsafe_allow_html=True)
    render_card_header("Migration Decision Log")
    df = pd.DataFrame(columns=["Timestamp", "VM ID", "Source Node", "Dest Node", "Reason", "Status"])
    st.dataframe(df, use_container_width=True, hide_index=True)
""")

    create_file(f"{base_dir}/modules/m09_power_management.py", """
import streamlit as st
from utils.ui import render_card_header, metric_box, status_badge, empty_chart

def render():
    st.markdown("<h2>AI-Based Server Power Management</h2>", unsafe_allow_html=True)
    st.markdown("<p>Optimizes server power states using workload, resource utilization, and carbon-aware intelligence.</p>", unsafe_allow_html=True)
    
    status_badge("Power Management Agent", "WAITING FOR TELEMETRY")
    
    st.markdown("<br/>", unsafe_allow_html=True)
    c1, c2, c3 = st.columns(3)
    with c1: metric_box("Total Power Draw", "N/A", "Watts")
    with c2: metric_box("Nodes in Sleep", "0", "Low power state")
    with c3: metric_box("Est. Power Saved", "N/A", "kWh")
    
    st.markdown("<br/>", unsafe_allow_html=True)
    render_card_header("Dynamic Voltage and Frequency Scaling (DVFS)")
    st.plotly_chart(empty_chart("CPU Frequency vs Power Draw"), use_container_width=True)
    
    st.markdown("<br/>", unsafe_allow_html=True)
    render_card_header("Idle Detection & Sleep Mode")
    st.markdown("<div style='padding: 2rem; border: 1px dashed var(--border); border-radius: 0.5rem; text-align: center; color: var(--muted);'>No idle nodes detected. Awaiting backend workload prediction.</div>", unsafe_allow_html=True)
""")

    create_file(f"{base_dir}/modules/m10_failure_prediction.py", """
import streamlit as st
import pandas as pd
from utils.ui import render_card_header, metric_box, status_badge, empty_chart

def render():
    st.markdown("<h2>Self-Healing Failure Prediction</h2>", unsafe_allow_html=True)
    st.markdown("<p>Predicts infrastructure failures and enables proactive recovery through intelligent management.</p>", unsafe_allow_html=True)
    
    status_badge("Failure Prediction Engine", "WAITING FOR BACKEND")
    
    st.markdown("<p style='color: var(--muted);'>No anomaly analysis is currently available.</p>", unsafe_allow_html=True)
    
    st.markdown("<br/>", unsafe_allow_html=True)
    c1, c2, c3 = st.columns(3)
    with c1: metric_box("Global Anomaly Score", "N/A", "Threshold: 0.85")
    with c2: metric_box("Predicted Failures", "0", "Next 24h")
    with c3: metric_box("Self-Healing Actions", "0", "Automated migrations")
    
    st.markdown("<br/>", unsafe_allow_html=True)
    render_card_header("CPU & RAM Abnormal Trends")
    st.plotly_chart(empty_chart("Anomaly Detection Trends"), use_container_width=True)
    
    st.markdown("<br/>", unsafe_allow_html=True)
    render_card_header("Migration/Self-Healing Action Log")
    df = pd.DataFrame(columns=["Timestamp", "Node", "Anomaly Score", "Failure Prob.", "Recommended Action", "Status"])
    st.dataframe(df, use_container_width=True, hide_index=True)
""")

    create_file(f"{base_dir}/modules/m11_sustainability.py", """
import streamlit as st
import pandas as pd
from utils.ui import render_card_header, metric_box, empty_chart

def render():
    st.markdown("<h2>Sustainability Monitoring Dashboard</h2>", unsafe_allow_html=True)
    st.markdown("<p>Summarizes overall sustainability improvements and system performance.</p>", unsafe_allow_html=True)
    
    st.markdown("<br/>", unsafe_allow_html=True)
    render_card_header("Overall Sustainability Impact")
    c1, c2, c3, c4 = st.columns(4)
    with c1: metric_box("Total Carbon", "N/A", "gCO2eq")
    with c2: metric_box("Energy Consumed", "N/A", "kWh")
    with c3: metric_box("Renewable Ratio", "N/A", "%")
    with c4: metric_box("Carbon Saved", "N/A", "Compared to baseline")
    
    st.markdown("<br/>", unsafe_allow_html=True)
    c_chart1, c_chart2 = st.columns(2)
    with c_chart1: 
        render_card_header("Carbon, Energy & Renewable Results")
        st.plotly_chart(empty_chart("Carbon Emissions by Module"), use_container_width=True)
    with c_chart2: 
        render_card_header("Scheduling & Simulation Results")
        st.plotly_chart(empty_chart("Energy Mix (Renewable vs Grid)"), use_container_width=True)
        
    st.markdown("<br/>", unsafe_allow_html=True)
    render_card_header("Data Export Controls")
    c_btn1, c_btn2, c_btn3 = st.columns(3)
    with c_btn1: st.button("Export to PDF", disabled=True, use_container_width=True)
    with c_btn2: st.button("Export to CSV", disabled=True, use_container_width=True)
""")

    create_file(f"{base_dir}/modules/m12_system_health.py", """
import streamlit as st
from utils.ui import render_card_header, metric_box, status_badge

def render():
    st.markdown("<h2>System Health</h2>", unsafe_allow_html=True)
    st.markdown("<p>Monitors overall platform health and service connectivity.</p>", unsafe_allow_html=True)
    
    st.markdown("<br/>", unsafe_allow_html=True)
    c1, c2 = st.columns(2, gap="large")
    with c1:
        render_card_header("Core Services")
        status_badge("Database (MySQL)", "NOT CONNECTED")
        status_badge("WorkflowSim Engine", "WAITING")
        status_badge("CloudSim Plus Node", "WAITING")
        status_badge("K-Means Service", "WAITING")
        
    with c2:
        render_card_header("External APIs")
        status_badge("NASA POWER Weather API", "NOT CONNECTED")
        status_badge("Electricity Maps Grid API", "NOT CONNECTED")
        
    st.markdown("<br/>", unsafe_allow_html=True)
    render_card_header("System Metrics")
    c3, c4, c5 = st.columns(3)
    with c3: metric_box("System Uptime", "00:00:00", "Offline")
    with c4: metric_box("API Latency", "N/A", "ms")
    with c5: metric_box("Active Sessions", "0", "Awaiting backend")
""")

if __name__ == "__main__":
    generate_app()
    print("Streamlit high-fidelity build completed successfully.")
