import streamlit as st
from utils.ui import render_card_header, metric_box, status_badge, empty_chart

def render():
    st.markdown("<h2>AI-Based Server Power Management</h2>", unsafe_allow_html=True)
    st.markdown("<p>Optimizes server power states using workload, resource utilization, and carbon-aware intelligence.</p>", unsafe_allow_html=True)
    
    status_badge("Power Management Agent", "WAITING FOR TELEMETRY")
    
    st.markdown("<br/>", unsafe_allow_html=True)
    c1, c2, c3 = st.columns(3)
    with c1: metric_box("Total Power Draw", "N/A", "Watts")
    with c2: metric_box("Nodes in Sleep", "N/A", "Low power state")
    with c3: metric_box("Est. Power Saved", "N/A", "kWh")
    
    st.markdown("<br/>", unsafe_allow_html=True)
    render_card_header("Dynamic Voltage and Frequency Scaling (DVFS)")
    st.plotly_chart(empty_chart("CPU Frequency vs Power Draw", subtitle="No telemetry data available"), use_container_width=True)
    
    st.markdown("<br/>", unsafe_allow_html=True)
    render_card_header("Idle Detection & Sleep Mode")
    st.markdown("<div style='padding: 2rem; border: 1px dashed var(--border); border-radius: 0.5rem; text-align: center; color: var(--muted);'>WAITING FOR BACKEND<br/>No idle nodes or workload predictions available.</div>", unsafe_allow_html=True)
