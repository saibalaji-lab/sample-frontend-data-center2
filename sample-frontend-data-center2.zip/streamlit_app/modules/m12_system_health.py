import streamlit as st
from utils.ui import render_card_header, metric_box, status_badge

def render():
    st.markdown("<h2>System Health</h2>", unsafe_allow_html=True)
    st.markdown("<p>Monitors overall platform health and service connectivity.</p>", unsafe_allow_html=True)
    
    st.markdown("<br/>", unsafe_allow_html=True)
    c1, c2 = st.columns(2, gap="large")
    with c1:
        render_card_header("Core Services")
        status_badge("MySQL Database", "NOT CONNECTED")
        status_badge("WorkflowSim Engine", "NOT CONNECTED")
        status_badge("CloudSim Plus Node", "NOT CONNECTED")
        status_badge("K-Means Service", "NOT CONNECTED")
        
    with c2:
        render_card_header("External APIs")
        status_badge("NASA POWER", "NOT CONNECTED")
        status_badge("Electricity Maps", "NOT CONNECTED")
        
    st.markdown("<br/>", unsafe_allow_html=True)
    render_card_header("System Metrics")
    c3, c4, c5 = st.columns(3)
    with c3: metric_box("System Uptime", "N/A", "Offline")
    with c4: metric_box("API Latency", "N/A", "ms")
    with c5: metric_box("Active Sessions", "N/A", "Awaiting backend")
