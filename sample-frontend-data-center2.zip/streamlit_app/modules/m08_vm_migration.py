import streamlit as st
import pandas as pd
from utils.ui import render_card_header, metric_box, status_badge

def render():
    st.markdown("<h2>VM Migration</h2>", unsafe_allow_html=True)
    st.markdown("<p>Optimizes VM placement through migration and resource consolidation.</p>", unsafe_allow_html=True)
    
    status_badge("Migration Engine", "WAITING FOR OVERLOAD DETECTION")
    
    st.markdown("<br/>", unsafe_allow_html=True)
    c1, c2 = st.columns(2)
    with c1:
        render_card_header("Source (Overloaded Server)")
        st.markdown("<div style='padding: 2rem 1rem; border: 1px dashed var(--border); border-radius: 0.5rem; text-align: center; color: var(--muted);'>NO SOURCE CANDIDATE<br/>Awaiting backend resource mapping.</div>", unsafe_allow_html=True)
    with c2:
        render_card_header("Destination (Candidate Server)")
        st.markdown("<div style='padding: 2rem 1rem; border: 1px dashed var(--border); border-radius: 0.5rem; text-align: center; color: var(--muted);'>NO TARGET CANDIDATE<br/>Awaiting backend resource mapping.</div>", unsafe_allow_html=True)
        
    st.markdown("<br/>", unsafe_allow_html=True)
    render_card_header("Migration Decision Log")
    df = pd.DataFrame(columns=["Timestamp", "VM ID", "Source Node", "Dest Node", "Reason", "Status"])
    st.dataframe(df, use_container_width=True, hide_index=True)
