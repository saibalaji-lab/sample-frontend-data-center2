import streamlit as st
import pandas as pd
from utils.ui import render_card_header, metric_box, status_badge, empty_chart

def render():
    st.markdown("<h2>Resource Monitoring</h2>", unsafe_allow_html=True)
    st.markdown("<p>Monitors real-time resource utilization across the cloud data center.</p>", unsafe_allow_html=True)
    
    status_badge("Google/Alibaba Cluster Trace", "WAITING FOR RESOURCE TRACE")
    
    st.markdown("<br/>", unsafe_allow_html=True)
    c1, c2, c3 = st.columns(3)
    with c1: metric_box("Avg CPU Utilization", "N/A", "Across all nodes")
    with c2: metric_box("Avg RAM Utilization", "N/A", "Across all nodes")
    with c3: metric_box("Active Nodes", "N/A", "Servers online")
    
    st.markdown("<br/>", unsafe_allow_html=True)
    c_chart1, c_chart2 = st.columns(2)
    with c_chart1: 
        render_card_header("CPU Utilization (%)")
        st.plotly_chart(empty_chart("CPU Utilization Timeline", subtitle="No trace data available"), use_container_width=True)
    with c_chart2: 
        render_card_header("RAM Utilization (%)")
        st.plotly_chart(empty_chart("RAM Utilization Timeline", subtitle="No trace data available"), use_container_width=True)
    
    st.markdown("<br/>", unsafe_allow_html=True)
    render_card_header("Server Comparison")
    df = pd.DataFrame(columns=["Server ID", "CPU (%)", "RAM (%)", "Status", "Power Draw (W)"])
    st.dataframe(df, use_container_width=True, hide_index=True)
