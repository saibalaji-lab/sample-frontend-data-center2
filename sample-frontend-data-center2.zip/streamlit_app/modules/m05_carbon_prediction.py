import streamlit as st
import pandas as pd
from utils.ui import render_card_header, metric_box, status_badge, empty_chart

def render():
    st.markdown("<h2>AI-Based Carbon Prediction</h2>", unsafe_allow_html=True)
    st.markdown("<p>Predict carbon intensity using AI-driven analysis to support carbon-aware scheduling.</p>", unsafe_allow_html=True)
    
    status_badge("Carbon Residual LSTM V2", "READY FOR BACKEND INTEGRATION")
    
    st.markdown("<br/>", unsafe_allow_html=True)
    c1, c2, c3 = st.columns(3)
    with c1: metric_box("Current Intensity", "N/A", "gCO2eq/kWh")
    with c2: metric_box("24h Forecast Avg", "N/A", "gCO2eq/kWh")
    with c3: metric_box("Grid Status", "NO DATA", "Awaiting data")
    
    st.markdown("<br/>", unsafe_allow_html=True)
    render_card_header("Carbon Intensity Forecast")
    st.plotly_chart(empty_chart("Carbon Intensity (gCO2eq/kWh)", subtitle="Connect Carbon Residual LSTM V2 to generate forecast"), use_container_width=True)
    
    st.markdown("<br/>", unsafe_allow_html=True)
    render_card_header("Prediction Data Table")
    df = pd.DataFrame(columns=["Timestamp", "Predicted Intensity", "Actual Intensity", "Variance"])
    st.dataframe(df, use_container_width=True, hide_index=True)
