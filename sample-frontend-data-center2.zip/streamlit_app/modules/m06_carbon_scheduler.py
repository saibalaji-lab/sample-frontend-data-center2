import streamlit as st
import pandas as pd
from utils.ui import render_card_header, metric_box, status_badge

def render():
    st.markdown("<h2>Carbon-Aware Intelligent Resource Scheduler</h2>", unsafe_allow_html=True)
    st.markdown("<p>Schedules clustered tasks to the most sustainable servers.</p>", unsafe_allow_html=True)
    
    status_badge("Resource Scheduler", "WAITING FOR RESOURCE DATA")
    
    st.markdown("<br/>", unsafe_allow_html=True)
    c1, c2 = st.columns([2, 1], gap="large")
    
    with c1:
        render_card_header("Server Candidates")
        st.markdown("<div style='padding: 3rem 1rem; border: 1px dashed var(--border); border-radius: 0.5rem; text-align: center; color: var(--muted);'>NO RESOURCE CANDIDATES AVAILABLE<br/><br/>Awaiting resource trace and backend scheduling data.</div>", unsafe_allow_html=True)
            
    with c2:
        render_card_header("Selected Assignment")
        metric_box("Target Node", "WAITING", "No workflow scheduled")
        st.markdown("<br/>", unsafe_allow_html=True)
        render_card_header("Reasoning")
        st.markdown("<p style='font-size: 0.875rem;'>Awaiting backend evaluation metrics for carbon intensity and scheduling scores.</p>", unsafe_allow_html=True)
        
    st.markdown("<br/>", unsafe_allow_html=True)
    render_card_header("Scheduling Queue")
    df = pd.DataFrame(columns=["Task ID", "Cluster", "Target Server", "Estimated Carbon", "Status"])
    st.dataframe(df, use_container_width=True, hide_index=True)
