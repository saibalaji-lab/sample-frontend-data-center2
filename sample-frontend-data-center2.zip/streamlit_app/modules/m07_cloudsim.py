import streamlit as st
import pandas as pd
from utils.ui import render_card_header, metric_box, status_badge, empty_chart

def render():
    st.markdown("<h2>CloudSim Plus Simulation</h2>", unsafe_allow_html=True)
    st.markdown("<p>Simulate scheduled workflow execution across cloud resources and evaluate behavior.</p>", unsafe_allow_html=True)
    
    status_badge("CloudSim Plus Backend", "READY FOR INTEGRATION")
    
    st.markdown("<br/>", unsafe_allow_html=True)
    st.progress(0, text="Simulation Progress: WAITING FOR START")
    
    st.markdown("<br/>", unsafe_allow_html=True)
    c1, c2, c3, c4 = st.columns(4)
    with c1: metric_box("Total Tasks", "N/A", "In simulation")
    with c2: metric_box("Tasks Completed", "N/A", "Waiting")
    with c3: metric_box("VMs Active", "N/A", "Provisioned")
    with c4: metric_box("Sim Time", "N/A", "Virtual execution")
    
    st.markdown("<br/>", unsafe_allow_html=True)
    c_chart1, c_chart2 = st.columns(2)
    with c_chart1: 
        render_card_header("Workflow Execution Status")
        st.plotly_chart(empty_chart("Task Execution Timeline (Gantt)", subtitle="No simulation data available"), use_container_width=True)
    with c_chart2: 
        render_card_header("Resource Usage Monitoring")
        st.plotly_chart(empty_chart("VM Resource Allocation", subtitle="No simulation data available"), use_container_width=True)
    
    st.markdown("<br/>", unsafe_allow_html=True)
    render_card_header("Simulation Output Tables")
    df = pd.DataFrame(columns=["Time", "Event", "Task", "VM", "Details"])
    st.dataframe(df, use_container_width=True, hide_index=True)
