import streamlit as st
import pandas as pd
from utils.ui import render_card_header, metric_box, status_badge, empty_chart

def render():
    st.markdown("<h2>Renewable Energy Prediction</h2>", unsafe_allow_html=True)
    st.markdown("<p>Forecasts renewable energy availability to support carbon-aware cloud scheduling.</p>", unsafe_allow_html=True)
    
    status_badge("Renewable Residual LSTM V2", "WAITING FOR RENEWABLE MODEL")
    
    st.markdown("<br/>", unsafe_allow_html=True)
    c1, c2, c3, c4 = st.columns(4)
    with c1: metric_box("Model Setup", "LSTM V2", "Residual Network architecture")
    with c2: metric_box("RMSE", "N/A", "Root Mean Square Error")
    with c3: metric_box("MAE", "N/A", "Mean Absolute Error")
    with c4: metric_box("R² Score", "N/A", "Coefficient of Determination")
    
    st.markdown("<br/>", unsafe_allow_html=True)
    render_card_header("Renewable Generation Forecast")
    st.plotly_chart(empty_chart("Total Renewable Generation (MU)", subtitle="No prediction data available"), use_container_width=True)
    
    st.markdown("<br/>", unsafe_allow_html=True)
    render_card_header("Prediction Timeline")
    df = pd.DataFrame(columns=["Timestamp", "Total Renewable Generation (MU)", "Confidence"])
    st.dataframe(df, use_container_width=True, hide_index=True)
