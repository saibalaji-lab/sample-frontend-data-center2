import streamlit as st
import pandas as pd
from utils.ui import render_card_header, metric_box, empty_chart

def render():
    st.markdown("<h2>Sustainability Monitoring Dashboard</h2>", unsafe_allow_html=True)
    st.markdown("<p>Summarizes overall sustainability improvements and system performance.</p>", unsafe_allow_html=True)
    
    st.markdown("<br/>", unsafe_allow_html=True)
    render_card_header("Overall Sustainability Impact")
    c1, c2, c3, c4 = st.columns(4)
    with c1: metric_box("Total Carbon", "N/A", "gCO2eq")
    with c2: metric_box("Energy Consumed", "N/A", "kWh")
    with c3: metric_box("Renewable Ratio", "N/A", "%")
    with c4: metric_box("Carbon Saved", "N/A", "Compared to baseline")
    
    st.markdown("<br/>", unsafe_allow_html=True)
    c_chart1, c_chart2 = st.columns(2)
    with c_chart1: 
        render_card_header("Carbon, Energy & Renewable Results")
        st.plotly_chart(empty_chart("Carbon Emissions by Module", subtitle="No simulation data available"), use_container_width=True)
    with c_chart2: 
        render_card_header("Scheduling & Simulation Results")
        st.plotly_chart(empty_chart("Energy Mix (Renewable vs Grid)", subtitle="No simulation data available"), use_container_width=True)
        
    st.markdown("<br/>", unsafe_allow_html=True)
    render_card_header("Data Export Controls")
    c_btn1, c_btn2, c_btn3 = st.columns(3)
    with c_btn1: st.button("Export to PDF", disabled=True, use_container_width=True)
    with c_btn2: st.button("Export to CSV", disabled=True, use_container_width=True)
