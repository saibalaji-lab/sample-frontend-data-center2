import streamlit as st
import pandas as pd
from utils.ui import render_card_header, metric_box, status_badge, empty_chart

def render():
    st.markdown("<h2>Weather-Aware Carbon Forecast</h2>", unsafe_allow_html=True)
    st.markdown("<p>Uses weather and environmental conditions to support carbon-intensity forecasting.</p>", unsafe_allow_html=True)
    
    status_badge("NASA POWER Data Source", "NOT CONNECTED")
    
    st.markdown("<br/>", unsafe_allow_html=True)
    c1, c2, c3 = st.columns(3)
    with c1: metric_box("Surface Temp (C)", "N/A", "Latest reading")
    with c2: metric_box("Cloud Cover (%)", "N/A", "Latest reading")
    with c3: metric_box("Wind Speed (m/s)", "N/A", "Latest reading")
    
    st.markdown("<br/>", unsafe_allow_html=True)
    render_card_header("Weather Trends & Correlation")
    st.plotly_chart(empty_chart("Weather-Aware Correlation Analysis", subtitle="No correlation data available"), use_container_width=True)
    
    st.markdown("<br/>", unsafe_allow_html=True)
    render_card_header("NASA POWER Correlation Data")
    df = pd.DataFrame(columns=["Timestamp", "Temp (C)", "Cloud (%)", "Wind (m/s)", "Solar Irradiance"])
    st.dataframe(df, use_container_width=True, hide_index=True)
