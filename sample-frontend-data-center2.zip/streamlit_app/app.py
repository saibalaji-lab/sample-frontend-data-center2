import streamlit as st
from utils.state import init_session_state
from utils.theme import apply_theme
from components.header import render_header
from components.execution_platform import render_execution

st.set_page_config(page_title="AI Data Center", layout="wide", initial_sidebar_state="collapsed")

init_session_state()
apply_theme()

render_header()

if st.session_state.app_state == 'preparation':
    st.markdown('<div class="react-card" style="max-width: 900px; margin: 2rem auto;">', unsafe_allow_html=True)
    st.markdown('<div class="react-card-header">Workflow Intake</div>', unsafe_allow_html=True)
    
    col1, col2 = st.columns(2)
    with col1:
        st.markdown("### Upload DAX/XML Workflow")
        uploaded = st.file_uploader("Select file", type=["xml", "dax"])
        if uploaded:
            st.session_state.uploaded_file_name = uploaded.name
            st.session_state.upload_status = 'valid'
            
    with col2:
        st.markdown("### Workflow Snapshot")
        if st.session_state.uploaded_file_name:
            st.success(f"File validated: {st.session_state.uploaded_file_name}")
            st.info("Backend WorkflowSim parser NOT CONNECTED. Data extraction is pending.")
        else:
            st.markdown("<div style='padding: 2rem; border: 1px dashed var(--border); border-radius: 0.5rem; text-align: center; color: var(--muted);'>No workflow loaded.</div>", unsafe_allow_html=True)
            
    st.markdown("---")
    st.markdown("### Preparation Pipeline")
    c_p1, c_p2, c_p3 = st.columns(3)
    
    status = "WAITING" if st.session_state.upload_status == 'empty' else "READY FOR BACKEND"
    color_class = "badge-waiting" if status == "WAITING" else "badge-ready-for-backend"
    
    with c_p1:
        st.markdown(f"""<div class="metric-box" style="text-align: center;">
            <div class="metric-title">01 READ WORKFLOW</div>
            <div class="badge {color_class}">{status}</div>
        </div>""", unsafe_allow_html=True)
    with c_p2:
        st.markdown(f"""<div class="metric-box" style="text-align: center;">
            <div class="metric-title">02 EXTRACT INFO</div>
            <div class="badge {color_class}">{status}</div>
        </div>""", unsafe_allow_html=True)
    with c_p3:
        st.markdown(f"""<div class="metric-box" style="text-align: center;">
            <div class="metric-title">03 PREPROCESS</div>
            <div class="badge {color_class}">{status}</div>
        </div>""", unsafe_allow_html=True)
        
    st.markdown("<br/>", unsafe_allow_html=True)
    
    col_btn = st.columns([1,2,1])[1]
    with col_btn:
        st.markdown('<div class="stButton primary-btn">', unsafe_allow_html=True)
        if st.button("PROCEED TO EXECUTION", use_container_width=True, disabled=st.session_state.upload_status == 'empty'):
            st.session_state.app_state = 'execution'
            st.session_state.active_module_id = 'clustering'
            st.rerun()
        st.markdown('</div>', unsafe_allow_html=True)
        
    st.markdown('</div>', unsafe_allow_html=True)
    
elif st.session_state.app_state == 'execution':
    render_execution()
