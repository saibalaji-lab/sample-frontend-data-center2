import streamlit as st

def init_session_state():
    if 'theme' not in st.session_state:
        st.session_state.theme = 'dark'
    if 'app_state' not in st.session_state:
        st.session_state.app_state = 'preparation'
    if 'uploaded_file_name' not in st.session_state:
        st.session_state.uploaded_file_name = None
    if 'upload_status' not in st.session_state:
        st.session_state.upload_status = 'empty' # empty, valid
    if 'active_module_id' not in st.session_state:
        st.session_state.active_module_id = 'clustering'
