import streamlit as st

def apply_theme():
    if 'theme' not in st.session_state:
        st.session_state.theme = 'dark'
        
    theme = st.session_state.theme
    
    if theme == 'dark':
        css = """
        :root {
            --background: #09090b;
            --foreground: #fafafa;
            --surface: #18181b;
            --surface-elevated: #27272a;
            --border: #27272a;
            --accent: #2563eb;
            --accent-foreground: #ffffff;
            --muted: #a1a1aa;
            --muted-foreground: #71717a;
            --processing: #38bdf8;
            --error: #f87171;
            --warning: #fbbf24;
            --success: #4ade80;
        }
        """
    else:
        css = """
        :root {
            --background: #ffffff;
            --foreground: #09090b;
            --surface: #f4f4f5;
            --surface-elevated: #e4e4e7;
            --border: #e4e4e7;
            --accent: #2563eb;
            --accent-foreground: #ffffff;
            --muted: #52525b;
            --muted-foreground: #a1a1aa;
            --processing: #0284c7;
            --error: #ef4444;
            --warning: #f59e0b;
            --success: #22c55e;
        }
        """

    global_css = """
    <style>
    .stApp, .stApp > header { background-color: var(--background); color: var(--foreground); font-family: ui-sans-serif, system-ui, sans-serif; }
    header[data-testid="stHeader"] { display: none !important; }
    .block-container { padding-top: 0rem !important; padding-bottom: 2rem !important; max-width: 1400px; }
    div[data-testid="stSidebar"] { background-color: var(--background); border-right: 1px solid var(--border); }
    
    .react-card { background-color: var(--surface); border: 1px solid var(--border); border-radius: 1rem; padding: 1.5rem; box-shadow: 0 1px 2px 0 rgba(0, 0, 0, 0.05); }
    .react-card-header { font-size: 0.875rem; font-weight: 600; text-transform: uppercase; letter-spacing: 0.05em; color: var(--foreground); border-bottom: 1px solid var(--border); padding-bottom: 1rem; margin-bottom: 1rem; }
    
    .metric-box { background-color: var(--surface-elevated); border: 1px solid var(--border); border-radius: 0.5rem; padding: 1rem; height: 100%; display: flex; flex-direction: column; }
    .metric-title { color: var(--muted); font-size: 0.75rem; font-weight: 600; text-transform: uppercase; letter-spacing: 0.05em; margin-bottom: 0.5rem; }
    .metric-value { font-size: 1.5rem; font-weight: 700; color: var(--foreground); }
    .metric-subtitle { color: var(--muted-foreground); font-size: 0.75rem; margin-top: 0.25rem; }
    
    .badge { display: inline-flex; align-items: center; padding: 0.25rem 0.75rem; border-radius: 9999px; font-size: 0.75rem; font-weight: 600; text-transform: uppercase; letter-spacing: 0.05em; }
    .badge-waiting, .badge-not-connected { background-color: var(--surface-elevated); color: var(--muted); border: 1px solid var(--border); }
    .badge-processing { background-color: rgba(56, 189, 248, 0.1); color: var(--processing); border: 1px solid rgba(56, 189, 248, 0.2); }
    .badge-success, .badge-ready-for-backend { background-color: rgba(74, 222, 128, 0.1); color: var(--success); border: 1px solid rgba(74, 222, 128, 0.2); }
    .badge-warning { background-color: rgba(251, 191, 36, 0.1); color: var(--warning); border: 1px solid rgba(251, 191, 36, 0.2); }
    .badge-error { background-color: rgba(248, 113, 113, 0.1); color: var(--error); border: 1px solid rgba(248, 113, 113, 0.2); }
    
    .stButton.nav-button > button { width: 100%; text-align: left; background-color: transparent; border: none; color: var(--muted); padding: 0.5rem 0.75rem; justify-content: flex-start; font-weight: 500; border-radius: 0.5rem; transition: all 0.2s; }
    .stButton.nav-button > button:hover { background-color: var(--surface-elevated); color: var(--foreground); }
    .stButton.nav-button-active > button { background-color: rgba(37, 99, 235, 0.1); color: var(--accent); border: none; font-weight: 600; text-align: left; padding: 0.5rem 0.75rem; justify-content: flex-start; width: 100%; border-radius: 0.5rem; }
    .stButton.nav-button-active > button p, .stButton.nav-button > button p { font-size: 0.8rem; }
    
    .stButton.primary-btn > button { background-color: var(--accent); color: var(--accent-foreground); border: none; border-radius: 0.5rem; font-weight: 600; text-transform: uppercase; letter-spacing: 0.05em; padding: 0.75rem 2rem; }
    .stButton.primary-btn > button:hover { background-color: #1d4ed8; color: #ffffff; }
    
    h1, h2, h3, h4, h5, h6 { color: var(--foreground) !important; }
    p { color: var(--muted); }
    [data-testid="stDataFrame"] { border-radius: 0.5rem; border: 1px solid var(--border); }
    </style>
    """
    
    st.markdown(global_css + css, unsafe_allow_html=True)
