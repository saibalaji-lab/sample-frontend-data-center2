import streamlit as st
import plotly.graph_objects as go

def metric_box(title, value, subtitle=""):
    st.markdown(f"""
    <div class="metric-box">
        <div class="metric-title">{title}</div>
        <div class="metric-value">{value}</div>
        <div class="metric-subtitle">{subtitle}</div>
    </div>
    """, unsafe_allow_html=True)

def status_badge(label, status="WAITING"):
    status_lower = status.lower().replace(" ", "-")
    st.markdown(f"""
    <div style="display: flex; justify-content: space-between; align-items: center; padding: 0.75rem; background-color: var(--surface-elevated); border: 1px solid var(--border); border-radius: 0.5rem; margin-bottom: 0.5rem;">
        <div style="font-weight: 500; color: var(--foreground); font-size: 0.875rem;">{label}</div>
        <div class="badge badge-{status_lower}">{status}</div>
    </div>
    """, unsafe_allow_html=True)

def empty_chart(title, subtitle="No Data Available", height=300):
    theme = st.session_state.theme
    bg_color = "#18181b" if theme == "dark" else "#f4f4f5"
    text_color = "#a1a1aa" if theme == "dark" else "#71717a"
    
    fig = go.Figure()
    fig.add_annotation(text=subtitle, xref="paper", yref="paper", showarrow=False, font=dict(size=14, color=text_color))
    fig.update_layout(
        height=height, 
        template="plotly_dark" if theme == "dark" else "plotly_white", 
        title=dict(text=title, font=dict(size=14, color=text_color)), 
        margin=dict(l=0, r=0, t=40, b=0),
        paper_bgcolor=bg_color, 
        plot_bgcolor=bg_color,
        xaxis=dict(showgrid=False, zeroline=False, showticklabels=False),
        yaxis=dict(showgrid=False, zeroline=False, showticklabels=False)
    )
    return fig

def render_card_header(title):
    st.markdown(f'<div class="react-card-header">{title}</div>', unsafe_allow_html=True)
