import streamlit as st

CATEGORIES = {
    'WORKFLOW': [
        ('clustering', '01 Dynamic Workflow Clustering'), 
        ('resources', '02 Resource Monitoring')
    ],
    'AI INTELLIGENCE': [
        ('renewable', '03 Renewable Energy Prediction'), 
        ('weather', '04 Weather-Aware Carbon Forecast'), 
        ('carbon', '05 AI-Based Carbon Prediction')
    ],
    'OPTIMIZATION': [
        ('scheduler', '06 Intelligent Resource Scheduler'),
        ('simulation', '07 CloudSim Plus Simulation'), 
        ('migration', '08 VM Migration'), 
        ('power', '09 AI Server Power Management')
    ],
    'RELIABILITY': [
        ('failure', '10 Self-Healing Failure Prediction')
    ],
    'RESULTS': [
        ('results', '11 Sustainability Dashboard'),
        ('system', '12 System Health')
    ]
}

def render_sidebar():
    st.markdown('<div style="padding: 0.5rem 0;">', unsafe_allow_html=True)
    
    for category, modules in CATEGORIES.items():
        st.markdown(f'<div style="font-size: 0.7rem; font-weight: 700; color: var(--muted-foreground); text-transform: uppercase; letter-spacing: 0.1em; margin-top: 1.5rem; margin-bottom: 0.5rem; padding-left: 0.5rem;">{category}</div>', unsafe_allow_html=True)
        for m_id, title in modules:
            is_active = st.session_state.active_module_id == m_id
            btn_class = "nav-button-active" if is_active else "nav-button"
            
            st.markdown(f'<div class="stButton {btn_class}">', unsafe_allow_html=True)
            if st.button(title, key=f"nav_{m_id}", use_container_width=True):
                st.session_state.active_module_id = m_id
                st.rerun()
            st.markdown('</div>', unsafe_allow_html=True)
            
    st.markdown('</div>', unsafe_allow_html=True)
