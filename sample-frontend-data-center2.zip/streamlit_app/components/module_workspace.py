import streamlit as st
from modules import m01_clustering, m02_resource_monitoring, m03_renewable_energy, m04_weather_carbon, m05_carbon_prediction, m06_carbon_scheduler, m07_cloudsim, m08_vm_migration, m09_power_management, m10_failure_prediction, m11_sustainability, m12_system_health

MODULE_MAP = {
    'clustering': m01_clustering.render,
    'resources': m02_resource_monitoring.render,
    'renewable': m03_renewable_energy.render,
    'weather': m04_weather_carbon.render,
    'carbon': m05_carbon_prediction.render,
    'scheduler': m06_carbon_scheduler.render,
    'simulation': m07_cloudsim.render,
    'migration': m08_vm_migration.render,
    'power': m09_power_management.render,
    'failure': m10_failure_prediction.render,
    'results': m11_sustainability.render,
    'system': m12_system_health.render
}

ORDERED_IDS = list(MODULE_MAP.keys())

def render_workspace(active_id):
    st.markdown('<div class="react-card">', unsafe_allow_html=True)
    if active_id in MODULE_MAP:
        MODULE_MAP[active_id]()
    st.markdown('</div>', unsafe_allow_html=True)
    
    # Bottom Navigation
    st.markdown("<br/>", unsafe_allow_html=True)
    c_back, c_space, c_next = st.columns([2, 6, 2])
    
    current_idx = ORDERED_IDS.index(active_id)
    
    with c_back:
        if st.button("← BACK", use_container_width=True):
            if current_idx == 0:
                st.session_state.app_state = 'preparation'
            else:
                st.session_state.active_module_id = ORDERED_IDS[current_idx - 1]
            st.rerun()
            
    with c_next:
        if current_idx < len(ORDERED_IDS) - 1:
            st.markdown('<div class="stButton primary-btn">', unsafe_allow_html=True)
            if st.button("NEXT →", use_container_width=True):
                st.session_state.active_module_id = ORDERED_IDS[current_idx + 1]
                st.rerun()
            st.markdown('</div>', unsafe_allow_html=True)
