import streamlit as st
import streamlit.components.v1 as components

def render_header():
    theme = st.session_state.theme
    bg_color = "#09090b" if theme == "dark" else "#ffffff"
    text_color = "#fafafa" if theme == "dark" else "#09090b"
    border_color = "#27272a" if theme == "dark" else "#e4e4e7"
    accent = "#2563eb"
    
    html_code = f"""
    <div style="background-color: {bg_color}; border-bottom: 1px solid {border_color}; padding: 15px 20px; display: flex; justify-content: space-between; align-items: center; font-family: sans-serif;">
        <div style="display: flex; align-items: center; gap: 10px;">
            <div style="width: 24px; height: 24px; background-color: {accent}; border-radius: 4px;"></div>
            <span style="color: {text_color}; font-weight: bold; font-size: 16px;">Green Data Center</span>
            <span style="background-color: {accent}20; color: {accent}; padding: 2px 8px; border-radius: 12px; font-size: 12px; font-weight: bold;">v2.0.0</span>
        </div>
        <div style="display: flex; align-items: center; gap: 15px;">
            <div id="live-clock" style="color: {text_color}; opacity: 0.7; font-size: 14px; font-family: monospace;"></div>
        </div>
    </div>
    <script>
        function updateClock() {{
            document.getElementById('live-clock').innerText = new Date().toLocaleString();
        }}
        setInterval(updateClock, 1000);
        updateClock();
    </script>
    """
    components.html(html_code, height=55, margin=0)
    
    # Theme toggle
    col1, col2, col3 = st.columns([8,1,1])
    with col3:
        if st.button("🌓 Theme", use_container_width=True):
            st.session_state.theme = 'light' if st.session_state.theme == 'dark' else 'dark'
            st.rerun()
