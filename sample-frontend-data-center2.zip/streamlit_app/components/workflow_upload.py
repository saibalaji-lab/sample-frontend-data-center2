import streamlit as st

def render_workflow_upload():
    st.markdown("### Upload DAX/XML Workflow")
    uploaded_file = st.file_uploader("Select Workflow File", type=["xml", "dax"])
    if uploaded_file is not None:
        if st.session_state.uploaded_file != uploaded_file:
            st.session_state.uploaded_file = uploaded_file
            st.session_state.upload_state = "valid"
            # reset pipeline
            st.session_state.pipeline_stages = {
                "read": "WAITING", "extract": "WAITING", "preprocess": "WAITING"
            }
            st.rerun()
