import streamlit as st
from components.module_navigation import render_sidebar
from components.module_workspace import render_workspace

def render_execution():
    st.markdown("""
    <div style="text-align: center; padding: 2rem 0; border-bottom: 1px solid var(--border); margin-bottom: 2rem;">
        <h2 style="margin: 0; font-size: 1.5rem; font-weight: 700;">AI-Driven Carbon-Aware Dynamic Workflow Scheduling</h2>
        <div style="color: var(--muted); font-size: 1.125rem; margin-top: 0.5rem;">with Intelligent Resource Optimization for Sustainable Green Cloud Data Centers</div>
    </div>
    """, unsafe_allow_html=True)
    
    col_nav, col_work = st.columns([1, 4], gap="large")
    
    with col_nav:
        render_sidebar()
        
    with col_work:
        render_workspace(st.session_state.active_module_id)
