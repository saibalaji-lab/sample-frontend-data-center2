import streamlit as st

def render_preparation_pipeline():
    st.markdown("<h3 style='text-align: center;'>Preparation Pipeline</h3>", unsafe_allow_html=True)
    cols = st.columns(3)
    
    stages = [
        ("01", "READ WORKFLOW", st.session_state.pipeline_stages["read"]),
        ("02", "EXTRACT INFO", st.session_state.pipeline_stages["extract"]),
        ("03", "PREPROCESS", st.session_state.pipeline_stages["preprocess"])
    ]
    
    for i, col in enumerate(cols):
        num, title, state = stages[i]
        with col:
            st.markdown(f"""
                <div class='metric-card' style='text-align: center;'>
                    <div style='color: #a1a1aa; font-size: 0.8rem;'>{num}</div>
                    <div style='font-weight: bold; margin: 0.5rem 0;'>{title}</div>
                    <span class='status-badge status-{state.lower()}'>{state}</span>
                </div>
            """, unsafe_allow_html=True)
