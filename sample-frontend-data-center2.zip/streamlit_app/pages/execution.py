import streamlit as st
from modules.m01_clustering import render as render_clustering
from modules.m02_resource_monitoring import render as render_resource
from modules.m03_renewable_energy import render as render_renewable
from modules.m04_weather_carbon import render as render_weather
from modules.m05_carbon_prediction import render as render_carbon
from modules.m06_carbon_scheduler import render as render_scheduler
from modules.m07_cloudsim import render as render_cloudsim
from modules.m08_vm_migration import render as render_migration
from modules.m09_power_management import render as render_power
from modules.m10_failure_prediction import render as render_failure
from modules.m11_sustainability import render as render_sustainability
from modules.m12_system_health import render as render_health

MODULES = [
    ('clustering', '01. Dynamic Workflow Clustering', render_clustering),
    ('resources', '02. Resource Monitoring', render_resource),
    ('renewable', '03. Renewable Energy Prediction', render_renewable),
    ('weather', '04. Weather-Aware Carbon Forecast', render_weather),
    ('carbon', '05. AI-Based Carbon Prediction', render_carbon),
    ('scheduler', '06. Intelligent Resource Scheduler', render_scheduler),
    ('simulation', '07. CloudSim Plus Simulation', render_cloudsim),
    ('migration', '08. VM Migration', render_migration),
    ('power', '09. AI Server Power Management', render_power),
    ('failure', '10. Self-Healing Failure Prediction', render_failure),
    ('results', '11. Sustainability Dashboard', render_sustainability),
    ('system', '12. System Health', render_health)
]

def render_execution_platform():
    # Sidebar Navigation
    st.sidebar.markdown("### Execution Pipeline")
    
    module_ids = [m[0] for m in MODULES]
    
    # Handle direct clicks from sidebar buttons
    for m_id, m_title, _ in MODULES:
        if st.sidebar.button(
            m_title, 
            key=f"nav_{m_id}", 
            use_container_width=True,
            type="primary" if st.session_state.active_module_id == m_id else "secondary"
        ):
            st.session_state.active_module_id = m_id
            st.rerun()

    current_idx = module_ids.index(st.session_state.active_module_id)
    _, current_title, current_render_fn = MODULES[current_idx]
    
    st.markdown(f"## {current_title}")
    st.markdown("---")
    
    # Render active module
    current_render_fn()
    
    st.markdown("---")
    col_back, col_next = st.columns([1, 1])
    
    with col_back:
        if st.button("← BACK", use_container_width=True):
            if current_idx == 0:
                st.session_state.app_state = "preparation"
            else:
                st.session_state.active_module_id = module_ids[current_idx - 1]
            st.rerun()
            
    with col_next:
        if current_idx < len(module_ids) - 1:
            if st.button("NEXT →", use_container_width=True, type="primary"):
                st.session_state.active_module_id = module_ids[current_idx + 1]
                st.rerun()
