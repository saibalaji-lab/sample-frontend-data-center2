import os

def create_file(path, content):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, 'w', encoding='utf-8') as f:
        f.write(content.strip() + '\n')

def main():
    base_dir = "streamlit_app"
    
    # ---------------------------------------------------------
    # UTILS / UI HELPERS
    # ---------------------------------------------------------
    create_file(f"{base_dir}/utils/ui.py", """
import streamlit as st
import plotly.graph_objects as go

def metric_card(title, value, subtitle=""):
    st.markdown(f\"\"\"
    <div style="background-color: #18181b; border: 1px solid #27272a; border-radius: 0.5rem; padding: 1.25rem; margin-bottom: 1rem; height: 100%;">
        <div style="color: #a1a1aa; font-size: 0.75rem; font-weight: 600; text-transform: uppercase; letter-spacing: 0.05em;">{title}</div>
        <div style="font-size: 1.75rem; font-weight: 700; margin-top: 0.5rem; color: #fafafa;">{value}</div>
        <div style="color: #71717a; font-size: 0.875rem; margin-top: 0.25rem;">{subtitle}</div>
    </div>
    \"\"\", unsafe_allow_html=True)

def status_indicator(label, status="WAITING"):
    color = "#71717a"
    if status == "CONNECTED": color = "#4ade80"
    elif status == "WARNING": color = "#facc15"
    elif status == "ERROR": color = "#f87171"
    elif status == "PROCESSING": color = "#38bdf8"
    
    st.markdown(f\"\"\"
    <div style="display: flex; align-items: center; padding: 0.75rem; background-color: #18181b; border: 1px solid #27272a; border-radius: 0.5rem; margin-bottom: 0.5rem;">
        <div style="width: 10px; height: 10px; border-radius: 50%; background-color: {color}; margin-right: 1rem;"></div>
        <div style="flex-grow: 1; font-weight: 500; color: #fafafa;">{label}</div>
        <div style="font-size: 0.875rem; color: {color}; font-weight: 600;">{status}</div>
    </div>
    \"\"\", unsafe_allow_html=True)

def empty_chart(title, height=300):
    fig = go.Figure()
    fig.add_annotation(text="No Data Connected", xref="paper", yref="paper", showarrow=False, font=dict(size=14, color="#71717a"))
    fig.update_layout(
        height=height, 
        template="plotly_dark", 
        title=dict(text=title, font=dict(size=14, color="#a1a1aa")), 
        margin=dict(l=0, r=0, t=40, b=0),
        paper_bgcolor="#18181b", 
        plot_bgcolor="#18181b",
        xaxis=dict(showgrid=False, zeroline=False, showticklabels=False),
        yaxis=dict(showgrid=False, zeroline=False, showticklabels=False)
    )
    return fig
""")

    # ---------------------------------------------------------
    # MODULES 01-12
    # ---------------------------------------------------------
    
    create_file(f"{base_dir}/modules/m01_clustering.py", """
import streamlit as st
import pandas as pd
from utils.ui import metric_card, empty_chart

def render():
    st.info("Awaiting workflow task processing. Backend clustering algorithm not connected.", icon="ℹ️")
    
    c1, c2, c3, c4 = st.columns(4)
    with c1: metric_card("Total Tasks", "N/A", "Parsed from workflow")
    with c2: metric_card("Optimal Clusters (k)", "N/A", "Elbow method result")
    with c3: metric_card("Silhouette Score", "N/A", "Model confidence")
    with c4: metric_card("Status", "WAITING", "Clustering pending")
    
    st.markdown("### K-Means Feature Space")
    st.plotly_chart(empty_chart("Task Clustering Distribution"), use_container_width=True)
    
    st.markdown("### Task Assignment Table")
    df = pd.DataFrame(columns=["Task ID", "CPU Required", "RAM Required", "Execution Time", "Assigned Cluster"])
    st.dataframe(df, use_container_width=True, hide_index=True)
""")

    create_file(f"{base_dir}/modules/m02_resource_monitoring.py", """
import streamlit as st
import pandas as pd
from utils.ui import metric_card, empty_chart

def render():
    st.info("No server telemetry connected. Monitoring waiting for live data.", icon="ℹ️")
    
    st.markdown("### Global Resource Utilization")
    c1, c2, c3 = st.columns(3)
    with c1: metric_card("Avg CPU Utilization", "N/A", "Across all nodes")
    with c2: metric_card("Avg RAM Utilization", "N/A", "Across all nodes")
    with c3: metric_card("Active Nodes", "0 / 0", "Servers online")
    
    st.markdown("### Node Telemetry")
    c_chart1, c_chart2 = st.columns(2)
    with c_chart1: st.plotly_chart(empty_chart("CPU Utilization (%)"), use_container_width=True)
    with c_chart2: st.plotly_chart(empty_chart("RAM Utilization (%)"), use_container_width=True)
    
    st.markdown("### Server Comparison")
    df = pd.DataFrame(columns=["Server ID", "CPU (%)", "RAM (%)", "Status", "Power Draw (W)"])
    st.dataframe(df, use_container_width=True, hide_index=True)
""")

    create_file(f"{base_dir}/modules/m03_renewable_energy.py", """
import streamlit as st
import pandas as pd
from utils.ui import metric_card, empty_chart

def render():
    st.info("Renewable Residual LSTM V2 model disconnected. No forecast available.", icon="⚠️")
    
    st.markdown("### Prediction Model Metrics")
    c1, c2, c3, c4 = st.columns(4)
    with c1: metric_card("Model", "LSTM V2", "Residual Network")
    with c2: metric_card("RMSE", "N/A", "Root Mean Square Error")
    with c3: metric_card("MAE", "N/A", "Mean Absolute Error")
    with c4: metric_card("R² Score", "N/A", "Coefficient of Determination")
    
    st.markdown("### Renewable Generation Forecast")
    st.plotly_chart(empty_chart("Solar & Wind Generation Prediction (kW)"), use_container_width=True)
    
    st.markdown("### Prediction Timeline")
    df = pd.DataFrame(columns=["Timestamp", "Solar Predict (kW)", "Wind Predict (kW)", "Total Renewable (kW)", "Confidence"])
    st.dataframe(df, use_container_width=True, hide_index=True)
""")

    create_file(f"{base_dir}/modules/m04_weather_carbon.py", """
import streamlit as st
import pandas as pd
from utils.ui import metric_card, empty_chart

def render():
    st.info("NASA POWER API disconnected. Awaiting weather data.", icon="⚠️")
    
    c1, c2, c3 = st.columns(3)
    with c1: metric_card("Temperature", "N/A", "Surface Temp (C)")
    with c2: metric_card("Cloud Cover", "N/A", "Percentage (%)")
    with c3: metric_card("Wind Speed", "N/A", "Meters per second (m/s)")
    
    st.markdown("### Weather Trends & Correlation")
    st.plotly_chart(empty_chart("Weather-Aware Correlation Analysis"), use_container_width=True)
    
    st.markdown("### NASA POWER Forecast Data")
    df = pd.DataFrame(columns=["Timestamp", "Temp (C)", "Cloud (%)", "Wind (m/s)", "Solar Irradiance"])
    st.dataframe(df, use_container_width=True, hide_index=True)
""")

    create_file(f"{base_dir}/modules/m05_carbon_prediction.py", """
import streamlit as st
import pandas as pd
from utils.ui import metric_card, empty_chart

def render():
    st.info("Electricity Maps Grid API disconnected. Using Carbon Residual LSTM V2 placeholders.", icon="⚠️")
    
    st.markdown("### Carbon Intensity Prediction")
    c1, c2, c3 = st.columns(3)
    with c1: metric_card("Current Intensity", "N/A", "gCO2eq/kWh")
    with c2: metric_card("24h Forecast Avg", "N/A", "gCO2eq/kWh")
    with c3: metric_card("Grid Status", "UNKNOWN", "Awaiting data")
    
    st.plotly_chart(empty_chart("Carbon Intensity Forecast (gCO2eq/kWh)"), use_container_width=True)
    
    st.markdown("### Intensity Table")
    df = pd.DataFrame(columns=["Timestamp", "Predicted Intensity", "Actual Intensity", "Variance"])
    st.dataframe(df, use_container_width=True, hide_index=True)
""")

    create_file(f"{base_dir}/modules/m06_carbon_scheduler.py", """
import streamlit as st
import pandas as pd
from utils.ui import metric_card

def render():
    st.info("Awaiting workflow parsing, carbon predictions, and resource telemetry for scheduling.", icon="ℹ️")
    
    st.markdown("### Carbon-Aware Intelligent Resource Scheduler")
    c1, c2 = st.columns([2, 1])
    
    with c1:
        st.markdown("#### Server Candidates")
        col_s1, col_s2 = st.columns(2)
        with col_s1:
            st.markdown(f\"\"\"
            <div style="background-color: #18181b; border: 1px solid #27272a; border-radius: 0.5rem; padding: 1rem; margin-bottom: 1rem; opacity: 0.5;">
                <div style="color: #fafafa; font-weight: bold; margin-bottom: 0.5rem;">Server Node A</div>
                <div style="color: #a1a1aa; font-size: 0.875rem;">CPU: N/A | RAM: N/A</div>
                <div style="color: #a1a1aa; font-size: 0.875rem;">Carbon Score: N/A</div>
                <div style="color: #a1a1aa; font-size: 0.875rem;">Schedule Score: N/A</div>
            </div>
            \"\"\", unsafe_allow_html=True)
        with col_s2:
            st.markdown(f\"\"\"
            <div style="background-color: #18181b; border: 1px solid #27272a; border-radius: 0.5rem; padding: 1rem; margin-bottom: 1rem; opacity: 0.5;">
                <div style="color: #fafafa; font-weight: bold; margin-bottom: 0.5rem;">Server Node B</div>
                <div style="color: #a1a1aa; font-size: 0.875rem;">CPU: N/A | RAM: N/A</div>
                <div style="color: #a1a1aa; font-size: 0.875rem;">Carbon Score: N/A</div>
                <div style="color: #a1a1aa; font-size: 0.875rem;">Schedule Score: N/A</div>
            </div>
            \"\"\", unsafe_allow_html=True)
            
    with c2:
        st.markdown("#### Selected Assignment")
        metric_card("Target Node", "WAITING", "No workflow scheduled")
        st.markdown("#### Reasoning")
        st.markdown("<div style='color: #71717a; font-size: 0.875rem;'>Awaiting backend evaluation metrics.</div>", unsafe_allow_html=True)
        
    st.markdown("### Scheduling Queue")
    df = pd.DataFrame(columns=["Task ID", "Cluster", "Target Server", "Estimated Carbon", "Status"])
    st.dataframe(df, use_container_width=True, hide_index=True)
""")

    create_file(f"{base_dir}/modules/m07_cloudsim.py", """
import streamlit as st
import pandas as pd
from utils.ui import metric_card, empty_chart

def render():
    st.info("Simulation backend unavailable. CloudSim Plus waiting for execution trigger.", icon="ℹ️")
    
    st.markdown("### Simulation Status")
    st.progress(0, text="Simulation Progress: 0%")
    
    c1, c2, c3, c4 = st.columns(4)
    with c1: metric_card("Total Tasks", "N/A", "In simulation")
    with c2: metric_card("Tasks Completed", "0", "0%")
    with c3: metric_card("VMs Active", "0", "Provisioned")
    with c4: metric_card("Sim Time", "0ms", "Virtual execution")
    
    c_chart1, c_chart2 = st.columns(2)
    with c_chart1: st.plotly_chart(empty_chart("Task Execution Timeline (Gantt)"), use_container_width=True)
    with c_chart2: st.plotly_chart(empty_chart("VM Resource Allocation"), use_container_width=True)
    
    st.markdown("### Output Logs")
    df = pd.DataFrame(columns=["Time", "Event", "Task", "VM", "Details"])
    st.dataframe(df, use_container_width=True, hide_index=True)
""")

    create_file(f"{base_dir}/modules/m08_vm_migration.py", """
import streamlit as st
import pandas as pd
from utils.ui import metric_card

def render():
    st.info("Waiting for overloaded server detection. No migrations required currently.", icon="ℹ️")
    
    c1, c2 = st.columns(2)
    with c1:
        st.markdown("### Source (Overloaded)")
        metric_card("Server ID", "N/A", "No overload detected")
        st.markdown("<div style='color: #71717a;'>CPU: N/A | RAM: N/A</div>", unsafe_allow_html=True)
    with c2:
        st.markdown("### Destination (Candidate)")
        metric_card("Server ID", "N/A", "No target selected")
        st.markdown("<div style='color: #71717a;'>CPU: N/A | RAM: N/A</div>", unsafe_allow_html=True)
        
    st.markdown("### Migration Decision Log")
    df = pd.DataFrame(columns=["Timestamp", "VM ID", "Source Node", "Dest Node", "Reason", "Status"])
    st.dataframe(df, use_container_width=True, hide_index=True)
""")

    create_file(f"{base_dir}/modules/m09_power_management.py", """
import streamlit as st
from utils.ui import metric_card, empty_chart

def render():
    st.info("Power state telemetry unavailable. AI-Based Server Power Management is idle.", icon="ℹ️")
    
    c1, c2, c3 = st.columns(3)
    with c1: metric_card("Total Power Draw", "N/A", "Watts")
    with c2: metric_card("Nodes in Sleep", "0", "Low power state")
    with c3: metric_card("Est. Power Saved", "N/A", "kWh")
    
    st.markdown("### Dynamic Voltage and Frequency Scaling (DVFS)")
    st.plotly_chart(empty_chart("CPU Frequency vs Power Draw"), use_container_width=True)
    
    st.markdown("### Idle Detection & Sleep Mode")
    st.markdown("<div style='color: #71717a; padding: 2rem; text-align: center; border: 1px dashed #27272a; border-radius: 0.5rem;'>No idle nodes detected in current timeframe.</div>", unsafe_allow_html=True)
""")

    create_file(f"{base_dir}/modules/m10_failure_prediction.py", """
import streamlit as st
import pandas as pd
from utils.ui import metric_card, empty_chart

def render():
    st.info("No anomaly trends detected. System operating within normal parameters.", icon="✅")
    
    c1, c2, c3 = st.columns(3)
    with c1: metric_card("Global Anomaly Score", "N/A", "Threshold: 0.85")
    with c2: metric_card("Predicted Failures", "0", "Next 24h")
    with c3: metric_card("Self-Healing Actions", "0", "Automated migrations")
    
    st.plotly_chart(empty_chart("CPU/RAM Anomaly Detection Trends"), use_container_width=True)
    
    st.markdown("### Self-Healing Log")
    df = pd.DataFrame(columns=["Timestamp", "Node", "Anomaly Score", "Failure Prob.", "Recommended Action", "Status"])
    st.dataframe(df, use_container_width=True, hide_index=True)
""")

    create_file(f"{base_dir}/modules/m11_sustainability.py", """
import streamlit as st
import pandas as pd
from utils.ui import metric_card, empty_chart

def render():
    st.info("Awaiting complete execution results to populate the Sustainability Dashboard.", icon="ℹ️")
    
    st.markdown("### Overall Sustainability Impact")
    c1, c2, c3, c4 = st.columns(4)
    with c1: metric_card("Total Carbon", "N/A", "gCO2eq")
    with c2: metric_card("Energy Consumed", "N/A", "kWh")
    with c3: metric_card("Renewable Ratio", "N/A", "%")
    with c4: metric_card("Carbon Saved", "N/A", "Compared to baseline")
    
    c_chart1, c_chart2 = st.columns(2)
    with c_chart1: st.plotly_chart(empty_chart("Carbon Emissions by Module"), use_container_width=True)
    with c_chart2: st.plotly_chart(empty_chart("Energy Mix (Renewable vs Grid)"), use_container_width=True)
    
    st.markdown("### Executive Summary Report")
    st.button("Export to PDF", disabled=True, help="Requires completed simulation data")
    st.button("Export to CSV", disabled=True, help="Requires completed simulation data")
""")

    create_file(f"{base_dir}/modules/m12_system_health.py", """
import streamlit as st
from utils.ui import metric_card, status_indicator

def render():
    st.error("Backend services disconnected. Showing offline states.", icon="🚨")
    
    c1, c2 = st.columns(2)
    with c1:
        st.markdown("### Core Services")
        status_indicator("Database (MySQL)", "ERROR")
        status_indicator("WorkflowSim Engine", "WAITING")
        status_indicator("CloudSim Plus Node", "WAITING")
        status_indicator("K-Means Service", "WAITING")
        
    with c2:
        st.markdown("### External APIs")
        status_indicator("NASA POWER Weather API", "ERROR")
        status_indicator("Electricity Maps Grid API", "ERROR")
        
    st.markdown("### System Metrics")
    c3, c4, c5 = st.columns(3)
    with c3: metric_card("System Uptime", "00:00:00", "Offline")
    with c4: metric_card("API Latency", "N/A", "ms")
    with c5: metric_card("Active Sessions", "1", "Local UI")
""")

if __name__ == "__main__":
    main()
    print("Streamlit UI modules updated successfully.")
